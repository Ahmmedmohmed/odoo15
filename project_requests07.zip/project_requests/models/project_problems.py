from odoo import fields, api, models


class ProjectProblems(models.Model):
    _name = 'project.problems'

    problem = fields.Char(
        string='المشكلة',
        required=True
    )
    reason = fields.Char(
        string='سبب المشكلة'
    )
    solution = fields.Char(
        string='الحلول المقترحة'
    )
    note = fields.Text(
        string="ملاحظات"
    )
    problems_project_follow_id = fields.Many2one(
        'project.follow'
    )

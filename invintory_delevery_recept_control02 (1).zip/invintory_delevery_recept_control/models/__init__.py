# -*- coding: utf-8 -*-


from . import stock_picking
from . import project
from . import car_car
from . import fleet_vehicle
from . import fleet_equipment


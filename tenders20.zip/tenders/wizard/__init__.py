from . import payment_receipt_wizard
from . import wizard_not_a_word
from . import wizard_cancel
from . import wizard_apologize

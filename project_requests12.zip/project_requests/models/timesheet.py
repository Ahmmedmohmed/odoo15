
from odoo import fields, models, api, _


class Timesheet(models.Model):
    _name = "timesheet.timesheet"

    name = fields.Char(
        'Description'
    )
    date = fields.Date(
        'Date',
        default=fields.Date.today()
    )
    unit_amount = fields.Integer(
        'Days Spent'
    )
    employee_id = fields.Many2one(
        'res.users',
        default=lambda self: self.env.user
    )
    project_task_id = fields.Many2one(
        'project.task'
    )
    project_id = fields.Many2one(
        'project.project'
    )

from odoo import fields, api, models


class HeavyEquipment(models.Model):
    _name = 'heavy.equipment'

    fleet_id = fields.Many2one(
        'fleet.vehicle',
        string='المعدة'
    )
    related_fleet_id = fields.Many2one(
        string='المعدة',
        related='fleet_id'
    )
    partner_id = fields.Many2one(
        'res.partner',
        string='المورد'
    )
    work_hours = fields.Float(
        string='عدد ساعات العمل'
    )
    unit = fields.Many2one(
        'item.item',
        string='الوحدة'
    )
    rosary = fields.Selection([
        ('am', 'ص'),
        ('pm', 'م')],
        string="الوردية"
    )
    work = fields.Char(
        string='مكان وطبيعة العمل'
    )
    reason = fields.Text(
        string="سبب العطل ان وجد"
    )
    note = fields.Text(
        string="ملاحظات"
    )
    heavy_project_follow_id = fields.Many2one(
        'project.follow'
    )

from odoo import fields, api, models


class ApplicationRequest(models.Model):
    _name = 'application.request'

    job_id = fields.Many2one(
        'hr.job',
        string='مسمي الوظيفة',
        required=True,
    )
    description = fields.Char(
        string='موقف الوظيفة(استكال هيكل/مؤقت/مستحدث)',
    )
    qty = fields.Float(
        string='العدد المطلوب',
        required=True,
    )
    tag_ids = fields.Many2many(
        comodel_name="project.tags",
        string="العلامات"
    )
    note = fields.Char(
        string="ملاحظات"
    )
    project_id = fields.Many2one(
        'project.project',
        string='Project',
    )
    project_task_id = fields.Many2one(
        'project.task',
        string='Task',
    )

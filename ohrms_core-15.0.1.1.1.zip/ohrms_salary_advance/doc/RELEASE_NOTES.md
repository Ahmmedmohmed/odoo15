## Module <ohrms_salary_advance>

#### 18.10.2021
#### Version 15.0.1.0.0
##### ADD
- Initial commit for Open HRMS Project

#### 26.07.2022
#### Version 15.0.1.1.0
##### UPDATE
- Change the PO file
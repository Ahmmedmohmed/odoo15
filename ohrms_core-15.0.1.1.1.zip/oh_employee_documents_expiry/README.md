OH Employee Documents
---------------------
Supporting Addon for Open HRMS, Manages Employee Related Documents

Overview
--------
Each and every detail associated with an employee is useful for any organization for better Human resource management.
So the employee documents with such necessary information must be saved and used accordingly.
'Employee Documents' is a useful tool that can help you to store and manage the employee related
documents like certificates, appraisal reports, passport, license etc.
The application also allows you to set an alert message on reaching the expiration/any other
related dates of a document (like an expiration of passport)

Connect with experts
--------------------

If you have any question/queries/additional works on OpenHRMS or this module, You can drop an email directly to Cybrosys.

Contacts
--------
info - info@cybrosys.com
Nilmar Shereef

Website:
https://www.openhrms.com
https://www.cybrosys.com

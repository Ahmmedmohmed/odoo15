# -*- coding: utf-8 -*-

from odoo import models, fields, api,_

class CarCar(models.Model):
    _name = 'car.car'
    _description = 'car'

    date_and_time = fields.Datetime(default=fields.Datetime.now,string=" التاريخ والوقت")
    car_type = fields.Char(string="نوع السيارة")
    vendor_id = fields.Many2one("res.partner",string=" المورد")
    driver = fields.Char(string="السائق")
    uom_id = fields.Many2one("uom.uom",string="الوحدة")
    quantity = fields.Integer(string="الكمية ")
    meter_reading_start = fields.Float(string="سجل قراءة عداد اول")
    meter_reading_end = fields.Float(string=" سجل قراءة عداد اخر")
    total_meter_reading_km = fields.Float(string="عدد الكيلو متر ")
    payload_type = fields.Char(string=" طبيعة الحمولة")
    move_from = fields.Char(string="من  ")
    move_to = fields.Char(string="الي ")

    billed_cars = fields.Boolean(string=" تم الفوترة ",default=False)
    record_bill_state = fields.Selection([('not_billed','Not Billed'),
                                          ('billed','Billed'),],default='not_billed',copy=False)

    #
    # def action_create_bill_from_cars(self):
    #     for car in self:
    #         bills = self.env['account.move'].create({
    #             'move_type': 'in_invoice',
    #             'partner_id': car.vendor_id.id,
    #             'invoice_date': fields.Date.today(),
    #             'invoice_line_ids': [(0, 0, {
    #                 'name': car.car_type,
    #                 'quantity': car.quantity,
    #             })],
    #         })
    #
    #         car.billed_cars= True



    def action_create_bill_from_cars(self):
        #Group records by vendor
        vendor_dict = {}
        for record in self:
            if record.record_bill_state == 'not_billed':
                vendor = record.vendor_id
                if vendor not in vendor_dict:
                    vendor_dict[vendor] = []
                vendor_dict[vendor].append(record)
            print("vendor_dict",vendor_dict)

            #Create bills for each vendor
            created_bills = self.env['account.move']
            for vendor, records in vendor_dict.items():
                # Prepare invoice lines for this vendor
                invoice_lines = []
                for record in records:
                    invoice_lines.append((0, 0, {
                        'name': record.car_type,
                        'quantity': record.quantity,
                    }))
                    record.write({
                        'billed_cars': True,
                        'record_bill_state': 'billed'
                    })
                print("invoice_lines",invoice_lines)

                # Create the bill
                bill = self.env['account.move'].create({
                    'move_type': 'in_invoice',
                    'partner_id': vendor.id,
                    'invoice_date': fields.Date.today(),
                    'invoice_line_ids': invoice_lines,
                })
                created_bills += bill

    # def action_open_billed_cars(self):
    #     return {
    #         'type': 'ir.actions.act_window',
    #         'name': _('Billed Cars'),
    #         'res_model': 'car.car',
    #         'view_mode': 'tree,form',
    #         'record_bill_state': 'billed'
    #         }




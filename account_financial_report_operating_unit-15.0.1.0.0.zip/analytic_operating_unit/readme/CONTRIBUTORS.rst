* Jordi Ballester Alomar <jordi.ballester@eficent.com>
* Sudhir Arya <sudhir@erpharbor.com>
* Alan Ramos <alan.ramos@jarsa.com.mx>

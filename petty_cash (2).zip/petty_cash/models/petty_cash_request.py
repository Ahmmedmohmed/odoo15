from datetime import date

from odoo import fields, models, api
from odoo.exceptions import ValidationError


class PettyCashRequest(models.Model):
    _name = 'petty.cash.request'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    STATE_SELECTION = [
        ('draft', 'Draft'),
        ('requested', 'Requested'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    ]

    name = fields.Char()
    request_to = fields.Many2one(
        'hr.employee',
        string='Request To'
    )
    request_by = fields.Many2one(
        'hr.employee',
        string='Request By'
    )
    payment_journal = fields.Many2one(
        'account.journal',
        string='Payment Journal',
        domain=[('type', 'in', ['cash', 'bank'])]
    )
    petty_cash_journal = fields.Many2one(
        'account.journal',
        string='Petty Cash Journal',
        domain=[('type', 'in', ['cash', 'bank'])]
    )
    date = fields.Date(
        string='Date',
        default=fields.Date.today()
    )
    request_amount = fields.Float(
        string='Request Amount'
    )
    user = fields.Many2one(
        'res.users',
        string='User',
        default=lambda self: self.env.user
    )
    company = fields.Many2one(
        'res.company',
        string='Company',
        default=lambda self: self.env.company
    )
    state = fields.Selection(
        STATE_SELECTION,
        string='State',
        default='draft'
    )
    payment = fields.Many2one(
        'account.payment',
        string='Payment'
    )
    balance = fields.Float(
        related='petty_cash_journal.default_account_id.current_balance'
    )
    account_move_id = fields.Many2one(
        'account.move'
    )
    account_move_count = fields.Integer(
        compute='compute_account_move_count'
    )
    description = fields.Text()

    def compute_account_move_count(self):
        for rec in self:
            account_move_count = self.env['account.move'].search_count([
                ('id', '=', rec.account_move_id.id)
            ])
            if account_move_count:
                rec.account_move_count = account_move_count
            else:
                rec.account_move_count = 0

    def action_show_journal_entry(self):
        action = self.env.ref('account.action_move_journal_line').read()[0]
        if self.account_move_count == 1:
            action['views'] = [(self.env.ref('contract.view_account_move_contract_helper_form').id, 'form')]
            action['res_id'] = self.account_move_id.id
        else:
            action = {'type': 'ir.actions.act_window_close'}
        return action

    @api.model
    def create(self, vals):
        if vals.get('name', '/') == '/':
            vals['name'] = self.env['ir.sequence'].next_by_code('petty.cash.request.sequence')

        return super(PettyCashRequest, self).create(vals)

    def activity_schedule(self, act_type_xmlid, date_deadline, summary, note, **act_values):
        return super(PettyCashRequest, self).activity_schedule(
            act_type_xmlid,
            date_deadline=date_deadline,
            summary=summary,
            note=note,
            **act_values
        )

    def activity_feedback(self, act_type_xmlid, feedback):
        return super(PettyCashRequest, self).activity_feedback(
            act_type_xmlid,
            feedback=feedback
        )

    def action_request(self):
        self.activity_schedule('mail.mail_activity_data_todo', summary='Petty Cash Requested',
                               note='Please review this petty cash request', date_deadline=date.today(),
                               user_id=self.user.id)
        self.write({'state': 'requested'})

    def action_reject(self):
        self.activity_schedule('mail.mail_activity_data_todo', summary='Petty Cash Request Has Been Rejected',
                               note='', date_deadline=date.today(),
                               user_id=self.user.id)
        self.write({'state': 'rejected'})

    def approve(self):
        self.write({'state': 'approved'})

        payment = self.env['account.payment'].create({
            'journal_id': self.payment_journal.id,
            'destination_journal_id': self.petty_cash_journal.id,
            'amount': self.request_amount,
            'date': self.date,
            'is_internal_transfer': True,
            'payment_type': 'inbound',
        })

        self.payment = payment
        payment.action_post()

    def action_approve(self):
        if self.account_move_id:
            self.account_move_id = False
        lines = [(0, 0, {'account_id': self.petty_cash_journal.default_account_id.id,
                         'debit': self.request_amount,
                         'credit': 0.0,
                         }),
                 (0, 0, {'account_id': self.payment_journal.default_account_id.id,
                         'debit': 0.0,
                         'credit': self.request_amount,
                         })]
        move = self.env['account.move'].create({
            'move_type': 'entry',
            'ref': self.name,
            'date': self.date,
            'journal_id': self.petty_cash_journal.id,
            'line_ids': lines
        })
        self.account_move_id = move
        self.activity_schedule('mail.mail_activity_data_todo', date_deadline=date.today(),
                               summary='Petty Cash Request Has Been Approved',
                               note='',
                               user_id=self.user.id)
        self.ensure_one()
        self.approve()

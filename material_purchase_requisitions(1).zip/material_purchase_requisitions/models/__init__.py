# -*- coding: utf-8 -*-

from . import purchase_requisition
from . import purchase_requisition_line
from . import hr_employee
from . import hr_department
from . import stock_picking
from . import purchase_order

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:

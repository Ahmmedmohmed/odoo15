This module adds "Due date" field in Bank Statements Lines.
In reconciliation process add "Due date" field to use in validation process (use these date in Journal Items.

#. Enable 'Show Full Accounting Features'
#. Go to *Invoicing > Overview*.
#. Locate the bank kanban card and import or create a new statement on it (Set some Date Due in some transaction).
#. Go to Reconcile process and validate transaction previously edited.
#. Go to Invoicing > Accounting > Journal Items and check Due date from items created.

Go to Invoicing --> Configuration --> Settings
Check the "Filter all account move lines" checkbox. When checked, all the account move lines will be filtered by the selected date.

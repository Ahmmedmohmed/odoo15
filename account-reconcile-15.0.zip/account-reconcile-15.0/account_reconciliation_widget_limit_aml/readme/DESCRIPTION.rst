This module adds the option to filter all the account move lines by date in the reconciliation view, not only those coming from payments.

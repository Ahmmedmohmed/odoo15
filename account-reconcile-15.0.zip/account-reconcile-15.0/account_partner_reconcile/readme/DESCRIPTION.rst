This module adds the buttons "Match Receivables" (& "Match Payables") in the customer (& suppliers) form
view to allow to start the matching of invoices & payments for that partner.

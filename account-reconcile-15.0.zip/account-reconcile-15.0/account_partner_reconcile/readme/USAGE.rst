#. Enable 'Show Full Accounting Features'
#. Create a new Customer Invoice and Payment
#. Go to the Customer/Supplier view form and click on Match payments

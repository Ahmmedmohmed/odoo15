* Akretion
    * Alexis de Lattre <alexis.delattre@akretion.com>

* ForgeFlow
    * Jordi Ballester Alomar <jordi.ballester@forgeflow.com>

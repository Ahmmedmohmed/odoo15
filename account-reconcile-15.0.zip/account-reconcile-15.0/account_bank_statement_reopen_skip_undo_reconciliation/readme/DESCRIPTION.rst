After installing this module when you press the button "Reset to New" on a bank
statement that is in status 'Processing' the application will not unreconcile
or set to draft any previous reconciled bank statement lines.

The reconciled bank statement lines remain posted and reconciled. As soon as
you manually unreconcile the line the associated journal entry will be reset
back to the Draft status, if the statement is in "New" status.

This feature improves the usability of the bank statements, as it may be
frequent for a user to adjust the statement lines during the reconciliation
process, needing to Reset the status of the statement back to new in order to
introduce changes.

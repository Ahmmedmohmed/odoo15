
Provides tools to facilitate reconciliation.

* Display a button on Journal Items to show reconciled lines.
* Added Balance field in Journal Items (this feature
  is provided by account_balance_line).

.. image:: ./static/docs/journal_items.png
   :alt: Journal items
   :scale: 50 %

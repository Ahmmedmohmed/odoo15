This module restricts to cancel or reset to draft any invoice/journal entry that
has been reconciled (aka paid).

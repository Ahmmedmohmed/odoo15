To use this module, you need to:

#. Go to *Invoicing > Customers > Invoices*
#. Access an invoice that has a payment.
#. Click on the 'Reset to Draft' button and you will get an error
   message to prevent you from resetting the invoice to draft state because
   it has already an associated payment.

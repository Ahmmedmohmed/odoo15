To use this module, you need to:

* Go to 'Invoicing / Accounting / Actions / Mass Automatic Reconcile'.

* Create a new reconciliation profile, and select a new configuration entry
  with type 'Advanced. Product, purchase order line'.

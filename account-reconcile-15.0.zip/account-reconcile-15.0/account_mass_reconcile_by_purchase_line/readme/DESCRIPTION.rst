This module extends the functionality of account_mass_reconcile and
allow an user to reconcile debits and credits of an Account
using the PO Line and Product as key fields. This type of
reconciliation is to be used in the context of the Perpetual Inventory
accounting system, with the accrual account '*Goods Received Not Invoiced*'.

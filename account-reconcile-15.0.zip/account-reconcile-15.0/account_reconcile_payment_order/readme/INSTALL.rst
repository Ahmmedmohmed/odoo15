This module requires the module **account_payment_order**, available
in https://github.com/OCA/bank-payment.

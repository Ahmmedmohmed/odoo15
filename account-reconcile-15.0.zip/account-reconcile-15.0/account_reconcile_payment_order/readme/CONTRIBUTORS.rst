* Holger Brunn
* `Tecnativa <https://www.tecnativa.com>`__:

  * Pedro M. Baeza
  * João Marques
  * Carlos Roca

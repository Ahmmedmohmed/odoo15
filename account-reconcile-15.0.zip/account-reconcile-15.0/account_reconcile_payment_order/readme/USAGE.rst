#. Go to *Invoicing > Overview*.
#. Locate the bank kanban card and import or create a new statement on it.
#. When reconciling, it should just work. What the module does is to search for
   a finished payment order that has the same amount as the statement line. If
   any, generated move lines (bank or AR/AP ones) are automatically proposed
   for the reconciliation.

#. Go to *Settings > Users & Companies > Users*.
#. Give to your user the permission "Show Full Accounting Features".

This module restores account reconciliation widget moved from Odoo community to enterpise in V. 14.0
Provides two widgets designed to reconcile move lines in a easy way: one focused on bank statements and another for generic use.

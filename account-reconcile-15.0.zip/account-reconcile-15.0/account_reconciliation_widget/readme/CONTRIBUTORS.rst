* Tecnativa - Pedro M. Baeza
* Kelvzxu - Kelvin Leonardi Kohsasih

from . import res_config_settings

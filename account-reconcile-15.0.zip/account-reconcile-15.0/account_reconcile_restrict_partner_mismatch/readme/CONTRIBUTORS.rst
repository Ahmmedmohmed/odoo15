* `Tecnativa <https://www.tecnativa.com>`_:
  * Ernesto Tejeda
* `Trobz <https://trobz.com>`_:
  * Nguyen Ho <nguyenhk@trobz.com>

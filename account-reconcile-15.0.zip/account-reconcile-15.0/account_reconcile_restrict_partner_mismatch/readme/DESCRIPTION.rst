This module restricts reconciliation between journal items when:

 - both items have different partners
 - one item is with partner and the other without it

This rule applies only for journal items using receivable and payable account type.

As at the moment of installation some journal items could have been reconciled
using different partners, you can detect them in menu Accounting > Adviser >
Reconciled items with partner mismatch.

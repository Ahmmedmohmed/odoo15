Your user should be a Sales Manager or Accountant.

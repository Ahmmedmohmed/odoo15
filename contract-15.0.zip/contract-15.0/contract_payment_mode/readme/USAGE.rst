#. Go to *Accounting > Sales > Contracts*.
#. Create one.
#. Select a partner to which invoice.
#. If the partner has a payment mode, this payment mode is selected here.
#. If not, or if you want another payment mode, you can change it in the
   corresponding field.
#. Click on **Generate recurring invoices automatically** checkbox.
#. Add a product to invoice.
#. If you create an invoice, new invoice will have the selected payment mode.

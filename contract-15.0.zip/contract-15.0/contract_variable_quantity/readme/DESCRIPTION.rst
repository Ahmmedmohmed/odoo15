With this module, you will be able to define in recurring contracts some
lines with variable quantity according to a provided formula.

To use this module you need to:

#. Create an agreement related with a company group partner.
#. Create several invoices related with company group members.
#. Create rebate settlements from *Agreements > Settlements > Create Settlements*
   wizard

This module extends the functionality of agreement module to take into
account if agreements affect to all company group members.

* `Tecnativa <https://www.tecnativa.com>`_:

  * Carlos Dauden
  * Pedro M. Baeza
  * Carolina Fernandez

* `Guadaltech <https://www.guadaltech.es>`_:

  * Fernando La Chica <fernandolachica@gmail.com>

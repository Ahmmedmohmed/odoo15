To use this module, you need to:

#. Go to Invoicing > Sales > Contracts and select or create a new contract.
#. Check *Generate recurring invoices automatically*.
#. Add a new recurring invoicing line.
#. Select "Variable quantity" in column "Qty. type".
#. Select "Project Timesheets", "Tasks Timesheets" or "Analytic Same Product"
   depending on your need.

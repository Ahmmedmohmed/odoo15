To use this module, you need to:

#. Go to Invoicing > Sales > Contracts and select or create a new contract.
#. Check *Generate recurring invoices automatically*.
#. Mark the check "Invoice Pending Sales Orders".
#. On each invoicing, system will check if there's any pending sales orders
   with same analyitic account and will append the lines to the invoice being
   generated.

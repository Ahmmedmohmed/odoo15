To use this module:

#. Go to **Invoicing > Customers > Customer Contracts** if you are a billing
   user.
#. Select as many contracts as you want to update line prices.
#. Click on Action button and execute the wizard **Create revision of contract
   lines**.
#. Enter date start from which the new price will be valid and enter date
   end and percentage to increase old contract lines.
#. By clicking on Apply button, a new contract line will be created with
   a price increased accordingly to the percent entered. Old contract lines
   will have as ending date the day before the entered date.
#. When create invoices related to contracts selected, prices will be update
   with the prices that are not out of date.

#. When managing contract with recurrence on line level, you maybe want not
   to revise price for some lines.
   Check 'Never Revise Price' on line level to avoid price revisions.

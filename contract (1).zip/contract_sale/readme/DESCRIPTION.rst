This module allows access to contracts for sale employees without account
permissions.

Employees in sale security group "User: Only Own Documents", can only access
contracts created by themselves.

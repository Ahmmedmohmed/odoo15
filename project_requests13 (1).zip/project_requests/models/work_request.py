
from odoo import fields, models, api, _


class WorkRequest(models.Model):

    _name = "work.request"
    _rec_name = 'vehicle_request_id'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    vehicle_request_id = fields.Many2one(
        'vehicle.request'
    )
    project_id = fields.Many2one(
        'project.project',
        string='المشروع'
    )
    partner_id = fields.Many2one(
        'res.partner',
        string='Customer'
    )
    date = fields.Date()
    company_id = fields.Many2one(
        'res.company'
    )
    user_id = fields.Many2one(
        'res.users',
        string='Project Manager'
    )
    tag_ids = fields.Many2many(
        'project.tags',
        string='Tags'
    )
    work_request_lines = fields.One2many(
        'work.request.line',
        'work_request_id'
    )
    state = fields.Selection(
        [('draft', 'Draft'),
         ('open', 'Open'),
         ('closed', 'Closed')],
        default='draft',
        tracking=True
    )

    open_date = fields.Datetime(
        readonly=True
    )
    close_date = fields.Datetime(
        readonly=True
    )
    duration = fields.Float(
        string="Duration (Hours)",
        compute='_compute_duration',
        store=True,
        # digits=(12, 6)
    )
    def action_open(self):
        for rec in self:
            rec.state = 'open'
            rec.open_date = fields.datetime.now()
            if rec.user_id:
                activity_vals = {
                    'activity_type_id': self.env.ref('mail.mail_activity_data_todo').id,
                    'summary': 'Work Request opened',
                    'note': 'This work request is Opined ',
                    'date_deadline': fields.Date.today(),
                    'res_id': rec.id,
                    'res_model_id': self.env.ref('project_requests.model_work_request').id,
                    'user_id': rec.user_id.id,
                }
                self.env['mail.activity'].create(activity_vals)
        project_follow = self.env['project.follow'].search([('project_id','=',self.project_id.id)])
        print("project_follow  ",project_follow.project_id.name)
        if project_follow:
            project_follow.date = fields.Date.today()

            equipment_lines = []
            for line in self.work_request_lines:
                equipment_lines.append((0, 0, {
                    'related_fleet_id': line.fleet_id.id,
                        'partner_id': line.supplier_id.id,
                        'note': line.note,
                }))
                line.opened = True
            project_follow.write({
                'heavy_equipment_id': equipment_lines
            })


            # for line in self.work_request_lines:
            #     project_follow.heavy_equipment_id.append(0,0,{
            #         'related_fleet_id': line.fleet_id.id,
            #         # 'partner_id': self.partner_id.id,
            #     })
                # project_follow.heavy_equipment_id.create({
                #     'related_fleet_id': line.fleet_id.id,
                #     'partner_id': self.partner_id.id,
                # })
        # for rec in self.work_request_lines:
        #     print(">",rec.vehicle_type_id,rec.fleet_id)
        #     fleet_report = self.env['heavy.equipment'].create({
        #         'related_fleet_id':rec.fleet_id.id,
        #         'partner_id':self.partner_id.id,
        #         # 'partner_id':self.partner_id.id,    self or rec
        #     })

    def action_close(self):
        for rec in self:
            rec.state = 'closed'
            rec.close_date = fields.datetime.now()
            if rec.user_id:
                activity_vals = {
                    'activity_type_id': self.env.ref('mail.mail_activity_data_todo').id,
                    'summary': 'Work Request closed',
                    'note': 'This work request is closed ',
                    'date_deadline': fields.Date.today(),
                    'res_id': rec.id,
                    'res_model_id': self.env.ref('project_requests.model_work_request').id,
                    'user_id': rec.user_id.id,
                }
                self.env['mail.activity'].create(activity_vals)


    @api.depends('open_date', 'close_date', 'state')
    def _compute_duration(self):
        for rec in self:
            if rec.open_date and rec.close_date and rec.state == 'closed':
                delta = rec.close_date - rec.open_date
                # Calculate total hours including fractional hours
                rec.duration = delta.total_seconds() / 3600
            else:
                rec.duration = 0.0




class WorkRequestLine(models.Model):

    _name = "work.request.line"

    work_request_id = fields.Many2one(
        'work.request'
    )
    description = fields.Char(
        # required=True
    )

    vehicle_type_id = fields.Many2one(
        'vehicle.type'
    )
    fleet_id = fields.Many2one(
        'fleet.vehicle',
        string='نوع المعدة'
    )
    fleet_model_id = fields.Many2one(
        'fleet.vehicle.model',
        string='الموديل',
        related='fleet_id.model_id'
    )
    qty = fields.Float(
        string='العدد المطلوب',
        required=True,
    )
    tag_ids = fields.Many2many(
        comodel_name="project.tags",
        string="العلامات"
    )
    note = fields.Char(
        string="ملاحظات"
    )
    supplier_id = fields.Many2one(
        'res.partner',
        string='المورد'
    )

    closed = fields.Boolean(string="Close")
    opened = fields.Boolean(string="Opened")

    def action_open_from_lines(self):
        print("action_open_from_lines")
        self.opened = True

        # for rec in self:
        #     rec.state = 'open'
        #     rec.open_date = fields.datetime.now()
        #     if rec.user_id:
        #         activity_vals = {
        #             'activity_type_id': self.env.ref('mail.mail_activity_data_todo').id,
        #             'summary': 'Work Request opened',
        #             'note': 'This work request is Opined ',
        #             'date_deadline': fields.Date.today(),
        #             'res_id': rec.id,
        #             'res_model_id': self.env.ref('project_requests.model_work_request').id,
        #             'user_id': rec.user_id.id,
        #         }
        #         self.env['mail.activity'].create(activity_vals)
        project_follow = self.env['project.follow'].search([('project_id', '=', self.work_request_id.project_id.id)])
        # print("project_follow  ", project_follow.work_request_id.project_id.name)
        print("project_follow  ", self.work_request_id.project_id.name)
        if project_follow:
            # project_follow.date = fields.Date.today()

            # equipment_lines = []
            # for line in self.work_request_lines:
            # equipment_lines.append((0, 0, {
            #     'related_fleet_id': self.fleet_id.id,
            #     'partner_id': self.supplier_id.id,
            #     'note': self.note,
            # }))
            #
            # project_follow.write({
            #     'heavy_equipment_id': equipment_lines
            # })

            new_line = project_follow.heavy_equipment_id.create({
                'related_fleet_id': self.fleet_id.id,
                'partner_id': self.supplier_id.id,
                'note': self.note,
            })
            print("tttttttttttttttttttttttttttttttttttt")
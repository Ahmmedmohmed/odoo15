from odoo import fields, api, models


class HeavyEquipment(models.Model):
    _name = 'heavy.equipment'

    fleet_id = fields.Many2one(
        'fleet.vehicle',
        string='المعدة'
    )
    related_fleet_id = fields.Many2one(
        string='المعدة',
        related='fleet_id',
        readonly=False,
    )
    partner_id = fields.Many2one(
        'res.partner',
        string='المورد'
    )
    work_hours = fields.Float(
        string='عدد ساعات العمل'
    )
    waiting_time = fields.Float(
        string='وقت الانتظار'
    )
    total_work_hours = fields.Float(
        string='عدد ساعات العمل التراكمية',
        readonly=1
    )
    unit = fields.Many2one(
        'item.item',
        string='الوحدة'
    )
    selected_unit = fields.Selection(
        [('kilometers', 'km'),
         ('miles', 'Hours')],
        string="الوحدة",
        # required=1,
        default='kilometers'
    )


    rosary = fields.Selection([
        ('am', 'ص'),
        ('pm', 'م')],
        string="الوردية"
    )
    work = fields.Char(
        string='مكان وطبيعة العمل'
    )
    reason = fields.Text(
        string="سبب العطل ان وجد"
    )
    note = fields.Text(
        string="ملاحظات"
    )
    heavy_project_follow_id = fields.Many2one(
        'project.follow'
    )

    @api.model
    def create(self, vals):
        res = super(HeavyEquipment, self).create(vals)
        project_follow_records = self.env['project.follow'].search([
            ('project_id', '=', res.heavy_project_follow_id.project_id.id)
        ])
        res.total_work_hours = sum(project_follow_records.mapped('heavy_equipment_id.work_hours'))
        return res

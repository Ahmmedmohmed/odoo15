from odoo import models, fields, api
from odoo.exceptions import UserError


class TenderRequest(models.Model):
    _name = 'tender.request'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    code = fields.Char(string="Tender Code", readonly=True)
    customer = fields.Many2one('res.partner', string='Customer', required=True)
    tender_purpose = fields.Char('الغرض من المناقصة', required=True)
    date = fields.Date('Date', required=True)
    tender_number = fields.Char('Tender Number', required=True)
    tender_amount = fields.Float('Tender Amount', required=True)
    bid_from = fields.Date('Bid from', required=True)
    bid_to = fields.Date('Bid to', required=True)
    state = fields.Selection([
        ('draft', 'Draft'),
        ('submitted', 'Submitted'),
        ('approve_ceo', 'Approved (CEO)'),
        ('reject', 'Rejected'),
    ], readonly=True, default='draft', track_visibility='onchange')

    def action_submit(self):
        self.write({'state': 'submitted'})

    def action_approve_ceo(self):
        self.write({'state': 'approve_ceo'})
        self.env['letters.of.guarantee.request'].create({
            'beneficiary': self.customer.id,
            'letter_purpose': self.tender_purpose + " - " + self.tender_number,
            'letter_value': self.tender_amount,
        })

    def action_reject(self):
        self.write({'state': 'reject'})

    @api.model
    def create(self, vals):
        if not vals.get('code'):
            vals['code'] = self.env['ir.sequence'].next_by_code('tender.request.sequence') or '/'
        return super(TenderRequest, self).create(vals)

    def unlink(self):
        for tender_request in self:
            if tender_request.state == 'approve_ceo':
                raise UserError("You cannot delete a tender request that has been approved.")
        return super(TenderRequest, self).unlink()


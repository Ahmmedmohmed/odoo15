## Module <fleet_rental_dashboard>

#### 25.04.2023
#### Version 15.0.1.0.0
#### ADD
- Initial Commit for Fleet Rental Dashboard

from odoo import models, api, fields, _


class WizardProductTires(models.TransientModel):
    _name = 'wizard.product.tires'
    _description = "Wizard Product Tires"

    brand = fields.Char()
    size = fields.Char()
    width = fields.Char()
    aspect_ratio = fields.Char()

    def wizard_product_tires_button(self):
        domain = []
        if self.brand and self.size and self.width and self.aspect_ratio:
            domain = ['|', '|', '|',
                      ('product_brand_id.brand', 'ilike', self.brand),
                      ('product_size_id.size', 'ilike', self.size),
                      ('product_width_id.width', 'ilike', self.width),
                      ('product_aspect_ratio_id.aspect_ratio', 'ilike', self.aspect_ratio)]
        elif self.brand and self.size and self.width:
            domain = ['|', '|',
                      ('product_brand_id.brand', 'ilike', self.brand),
                      ('product_size_id.size', 'ilike', self.size),
                      ('product_width_id.width', 'ilike', self.width)]
        elif self.brand and self.size and self.aspect_ratio:
            domain = ['|', '|',
                      ('product_brand_id.brand', 'ilike', self.brand),
                      ('product_size_id.size', 'ilike', self.size),
                      ('product_aspect_ratio_id.aspect_ratio', 'ilike', self.aspect_ratio)]
        elif self.brand and self.width and self.aspect_ratio:
            domain = ['|', '|',
                      ('product_brand_id.brand', 'ilike', self.brand),
                      ('product_width_id.width', 'ilike', self.width),
                      ('product_aspect_ratio_id.aspect_ratio', 'ilike', self.aspect_ratio)]
        elif self.size and self.width and self.aspect_ratio:
            domain = ['|', '|',
                      ('product_size_id.size', 'ilike', self.size),
                      ('product_width_id.width', 'ilike', self.width),
                      ('product_aspect_ratio_id.aspect_ratio', 'ilike', self.aspect_ratio)]
        elif self.brand and self.size:
            domain = ['|',
                      ('product_brand_id.brand', 'ilike', self.brand),
                      ('product_size_id.size', 'ilike', self.size)]
        elif self.brand and self.width:
            domain = ['|',
                      ('product_brand_id.brand', 'ilike', self.brand),
                      ('product_width_id.width', 'ilike', self.width)]
        elif self.brand and self.aspect_ratio:
            domain = ['|',
                      ('product_brand_id.brand', 'ilike', self.brand),
                      ('product_aspect_ratio_id.aspect_ratio', 'ilike', self.aspect_ratio)]
        elif self.size and self.width:
            domain = ['|',
                      ('product_size_id.size', 'ilike', self.size),
                      ('product_width_id.width', 'ilike', self.width)]
        elif self.size and self.aspect_ratio:
            domain = ['|',
                      ('product_size_id.size', 'ilike', self.size),
                      ('product_aspect_ratio_id.aspect_ratio', 'ilike', self.aspect_ratio)]
        elif self.width and self.aspect_ratio:
            domain = ['|',
                      ('product_width_id.width', 'ilike', self.width),
                      ('product_aspect_ratio_id.aspect_ratio', 'ilike', self.aspect_ratio)]
        elif self.brand:
            domain = [('product_brand_id.brand', 'ilike', self.brand)]
        elif self.width:
            domain = [('product_width_id.width', 'ilike', self.width)]
        elif self.size:
            domain = [('product_size_id.size', 'ilike', self.size)]
        elif self.aspect_ratio:
            domain = [('product_aspect_ratio_id.aspect_ratio', 'ilike', self.aspect_ratio)]

        product_records = self.env['product.template'].search(domain)
        return {
            'name': _('Products Filtered'),
            'type': 'ir.actions.act_window',
            'view_mode': 'tree',
            'target': 'new',
            'res_model': 'product.template',
            'view_id': self.env.ref('product.product_template_tree_view').id,
            'domain': [('id', 'in', product_records.ids)],
        }

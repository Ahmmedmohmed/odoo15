
from . import wizard_product_tires

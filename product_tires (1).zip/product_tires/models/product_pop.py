from odoo import _, api, fields, models


class ProductPop(models.Model):
    _name = 'product.pop'
    _rec_name = 'pop'

    pop = fields.Char(
        required=1,
        string='Pop'
    )

from odoo import _, api, fields, models


class ProductYear(models.Model):
    _name = 'product.year'
    _rec_name = 'year'

    year = fields.Char(
        required=1,
        string='Year'
    )

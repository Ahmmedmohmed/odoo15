from odoo import _, api, fields, models


class ProductAspectRatio(models.Model):
    _name = 'product.aspect.ratio'
    _rec_name = 'aspect_ratio'

    aspect_ratio = fields.Char(
        required=1,
        string='Aspect Ratio'
    )

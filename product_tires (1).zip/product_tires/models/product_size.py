from odoo import _, api, fields, models


class ProductSize(models.Model):
    _name = 'product.size'
    _rec_name ='size'

    size = fields.Char(
        required=1,
        string='Size'
    )

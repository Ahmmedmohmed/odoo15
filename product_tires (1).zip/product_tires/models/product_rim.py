from odoo import _, api, fields, models


class ProductRim(models.Model):
    _name = 'product.rim'
    _rec_name = 'rim'

    rim = fields.Char(
        required=1,
        string='Rim'
    )

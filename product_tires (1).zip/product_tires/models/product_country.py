from odoo import _, api, fields, models


class ProductCountry(models.Model):
    _name = 'product.country'
    _rec_name = 'country'

    country = fields.Char(
        required=1,
        string='Country'
    )

from odoo import _, api, fields, models


class ProductWidth(models.Model):
    _name = 'product.width'
    _rec_name = 'width'

    width = fields.Char(
        required=1,
        string='Width'
    )

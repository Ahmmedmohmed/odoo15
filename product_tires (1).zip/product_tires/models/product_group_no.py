from odoo import _, api, fields, models


class ProductGroupNo(models.Model):
    _name = 'product.group.no'
    _rec_name = 'group_no'

    group_no = fields.Char(
        required=1,
        string='Group NO'
    )

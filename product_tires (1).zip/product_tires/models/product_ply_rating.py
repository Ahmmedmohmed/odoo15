from odoo import _, api, fields, models


class ProductPlyRating(models.Model):
    _name = 'product.ply.rating'
    _rec_name = 'ply_rating'

    ply_rating = fields.Char(
        required=1,
        string='PLY Rating'
    )

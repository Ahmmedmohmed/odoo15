from odoo import _, api, fields, models


class ProductBrand(models.Model):
    _name = 'product.brand'
    _rec_name = 'brand'

    brand = fields.Char(
        required=1,
        string='Brand'
    )

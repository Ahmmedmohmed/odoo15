from odoo import _, api, fields, models


class ProductCountryCode(models.Model):
    _name = 'product.country.code'
    _rec_name = 'country_code'

    country_code = fields.Char(
        required=1,
        string='Country Code'
    )

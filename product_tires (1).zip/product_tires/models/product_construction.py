from odoo import _, api, fields, models


class ProductConstruction(models.Model):
    _name = 'product.construction'
    _rec_name = 'construction'

    construction = fields.Char(
        required=1,
        string='Construction'
    )

from odoo import _, api, fields, models


class InheritProductTemplate(models.Model):
    _inherit = 'product.template'

    product_types = fields.Selection(
        [('tires', 'Tires'),
         ('batteries', 'Batteries'),
         ('parts', 'Parts'),
         ('others', 'Others')],
    )
    product_brand_id = fields.Many2one(
        'product.brand',
        string='Brand'
    )
    product_group_no_id = fields.Many2one(
        'product.group.no',
        string='Group No'
    )
    product_pattern_id = fields.Many2one(
        'product.pattern',
        string='Pattern'
    )
    product_size_id = fields.Many2one(
        'product.size',
        string='Size'
    )
    product_width_id = fields.Many2one(
        'product.width',
        string='Width'
    )
    product_aspect_ratio_id = fields.Many2one(
        'product.aspect.ratio',
        string='Aspect Ratio'
    )
    product_rim_id = fields.Many2one(
        'product.rim',
        string='Rim'
    )
    product_year_id = fields.Many2one(
        'product.year',
        string='Year'
    )
    product_tire_category_id = fields.Many2one(
        'product.tire.category',
        string='Tire Category'
    )
    product_construction_id = fields.Many2one(
        'product.construction',
        string='Construction'
    )
    product_ply_rating_id = fields.Many2one(
        'product.ply.rating',
        string='PLY Rating'
    )
    product_country_code_id = fields.Many2one(
        'product.country.code',
        string='Country Code'
    )
    product_country_id = fields.Many2one(
        'product.country',
        string='Country'
    )
    product_pop_id = fields.Many2one(
        'product.pop',
        string='POP'
    )

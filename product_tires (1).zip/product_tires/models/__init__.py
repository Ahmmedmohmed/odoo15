# -*- coding: utf-8 -*-

from . import product_template
from . import product_brand
from . import product_group_no
from . import product_pattern
from . import product_size
from . import product_width
from . import product_aspect_ratio
from . import product_rim
from . import product_year
from . import product_tire_category
from . import product_construction
from . import product_ply_rating
from . import product_country_code
from . import product_country
from . import product_pop

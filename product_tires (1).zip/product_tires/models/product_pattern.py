from odoo import _, api, fields, models


class ProductPattern(models.Model):
    _name = 'product.pattern'
    _rec_name = 'pattern'

    pattern = fields.Char(
        required=1,
        string='Pattern'
    )

from odoo import _, api, fields, models


class ProductTireCategory(models.Model):
    _name = 'product.tire.category'
    _rec_name = 'tire_category'

    tire_category = fields.Char(
        required=1,
        string='Tire Category'
    )

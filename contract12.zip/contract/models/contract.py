# Copyright 2004-2010 OpenERP SA
# Copyright 2014 Angel Moya <angel.moya@domatix.com>
# Copyright 2015-2020 Tecnativa - Pedro M. Baeza
# Copyright 2016-2018 Tecnativa - Carlos Dauden
# Copyright 2016-2017 LasLabs Inc.
# Copyright 2018 ACSONE SA/NV
# Copyright 2021 Tecnativa - Víctor Martínez
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).
import logging

from odoo import api, fields, models
from odoo.exceptions import UserError, ValidationError
from odoo.osv import expression
from odoo.tests import Form
from odoo.tools.translate import _
from datetime import timedelta, date

_logger = logging.getLogger(__name__)


class ContractContract(models.Model):
    _name = "contract.contract"
    _description = "Contract"
    _order = "code, name asc"
    _inherit = [
        "mail.thread",
        "mail.activity.mixin",
        "contract.abstract.contract",
        "contract.recurrency.mixin",
        "portal.mixin",
    ]

    name = fields.Char(required=0)
    active = fields.Boolean(
        default=True,
    )
    code = fields.Char(
        string="Reference",
    )
    group_id = fields.Many2one(
        string="Group",
        comodel_name="account.analytic.account",
        ondelete="restrict",
    )
    currency_id = fields.Many2one(
        compute="_compute_currency_id",
        inverse="_inverse_currency_id",
        comodel_name="res.currency",
        string="Currency",
    )
    manual_currency_id = fields.Many2one(
        comodel_name="res.currency",
        readonly=True,
    )
    contract_template_id = fields.Many2one(
        string="Contract Template", comodel_name="contract.template"
    )
    contract_line_ids = fields.One2many(
        string="Contract lines",
        comodel_name="contract.line",
        inverse_name="contract_id",
        copy=True,
        context={"active_test": False},
    )
    # Trick for being able to have 2 different views for the same o2m
    # We need this as one2many widget doesn't allow to define in the view
    # the same field 2 times with different views. 2 views are needed because
    # one of them must be editable inline and the other not, which can't be
    # parametrized through attrs.
    contract_line_fixed_ids = fields.One2many(
        string="Contract lines (fixed)",
        comodel_name="contract.line",
        inverse_name="contract_id",
        context={"active_test": False},
    )
    user_id = fields.Many2one(
        comodel_name="res.users",
        string="Responsible",
        index=True,
        default=lambda self: self.env.user,
    )
    create_invoice_visibility = fields.Boolean(
        compute="_compute_create_invoice_visibility"
    )
    date_end = fields.Date(compute="_compute_date_end", store=True, readonly=False)
    payment_term_id = fields.Many2one(
        comodel_name="account.payment.term", string="Payment Terms", index=True
    )
    invoice_count = fields.Integer(compute="_compute_invoice_count")
    fiscal_position_id = fields.Many2one(
        comodel_name="account.fiscal.position",
        string="Fiscal Position",
        ondelete="restrict",
    )
    invoice_partner_id = fields.Many2one(
        string="Invoicing contact",
        comodel_name="res.partner",
        ondelete="restrict",
        domain="['|',('id', 'parent_of', partner_id), ('id', 'child_of', partner_id)]",
    )
    partner_id = fields.Many2one(
        comodel_name="res.partner", inverse="_inverse_partner_id", required=True
    )
    commercial_partner_id = fields.Many2one(
        "res.partner",
        compute_sudo=True,
        related="partner_id.commercial_partner_id",
        store=True,
        string="Commercial Entity",
        index=True,
    )
    tag_ids = fields.Many2many(comodel_name="contract.tag", string="Tags")
    note = fields.Text(string="Notes")
    is_terminated = fields.Boolean(string="Terminated", readonly=True, copy=False)
    terminate_reason_id = fields.Many2one(
        comodel_name="contract.terminate.reason",
        string="Termination Reason",
        ondelete="restrict",
        readonly=True,
        copy=False,
        tracking=True,
    )
    terminate_comment = fields.Text(
        string="Termination Comment",
        readonly=True,
        copy=False,
        tracking=True,
    )
    terminate_date = fields.Date(
        string="Termination Date",
        readonly=True,
        copy=False,
        tracking=True,
    )
    modification_ids = fields.One2many(
        comodel_name="contract.modification",
        inverse_name="contract_id",
        string="Modifications",
    )

    end_date_extension = fields.Integer('End Date Extension', )
    new_end_date = fields.Date('New end date', readonly=True, compute="_compute_new_end_date", store=True)
    total_achievement = fields.Float(string='Total achievement %', readonly=True,
                                     compute="_compute_total_contract_achievement")
    total_invoice = fields.Float(string='Total Invoice', compute="_compute_total_invoice")
    total_remaining = fields.Float(string='Not completed', compute="_compute_total_remaining")
    total_paid = fields.Float(string='Total paid', compute="_compute_total_paid")
    receivable_amount = fields.Float(string='Receivable Amount', compute="_compute_receivable_amount")
    contract_value = fields.Float(string='Contract value', )
    contract_state = fields.Selection(selection=[
        ('running', 'Running'),
        ('finished', 'Finished'),
    ], string='Status',
        default='running')
    end_date_extension_line = fields.One2many('contract.extension.line', 'contract_id', string="contract")

    tax_type = fields.Selection(selection=[
        ('subject', 'خاضع'),
        ('unsubject', 'غير خاضع'),
        ('free', 'معفي'),
    ], string='Tax Type', default='free')
    tax_id = fields.Many2many('account.tax', string="Tax")
    site_receipt_date = fields.Date(string='Site Receipt Date')
    receiving_committee_date = fields.Date('Receiving committee')
    warranty_period_date = fields.Integer('Warranty Period Date')
    final_receipt_date = fields.Date('Final Receipt Date')
    project_id = fields.Many2one('project.project', string="Project")
    tender_number = fields.Char(
        'Tender Number'
    )
    tender_purpose = fields.Char(
        'الغرض من المناقصة'
    )

    def name_get(self):
        result = []
        for account in self:
            name = 'Contract - ' + str(account.id)
            result.append((account.id, name))
        return result

    @api.onchange('receiving_committee_date', 'warranty_period_date')
    def compute_final_receipt_date(self):
        for rec in self:
            if rec.warranty_period_date:
                if rec.receiving_committee_date:
                    # date_1 = datetime.datetime.strptime(rec.date_end, "%m/%d/%y")
                    days = rec.warranty_period_date
                    rec.final_receipt_date = rec.receiving_committee_date + timedelta(days=days)
                else:
                    rec.new_end_date = False

    @api.depends('end_date_extension_line')
    def _compute_new_end_date(self):
        for rec in self:
            lines = rec.env['contract.extension.line'].sudo().search(
                [('contract_id', '=', rec.id), ('check', '=', True)])
            if lines:
                rec.new_end_date = lines[-1].new_extension_date
            else:
                rec.new_end_date = False

    def get_formview_id(self, access_uid=None):
        if self.contract_type == "sale":
            return self.env.ref("contract.contract_contract_customer_form_view").id
        else:
            return self.env.ref("contract.contract_contract_supplier_form_view").id

    @api.model_create_multi
    def create(self, vals_list):
        records = super().create(vals_list)
        records._set_start_contract_modification()
        return records

    def write(self, vals):
        if "modification_ids" in vals:
            res = super(
                ContractContract, self.with_context(bypass_modification_send=True)
            ).write(vals)
            self._modification_mail_send()
        else:
            res = super(ContractContract, self).write(vals)
        return res

    @api.model
    def _set_start_contract_modification(self):
        subtype_id = self.env.ref("contract.mail_message_subtype_contract_modification")
        for record in self:
            if record.contract_line_ids:
                date_start = min(record.contract_line_ids.mapped("date_start"))
            else:
                date_start = record.create_date
            record.message_subscribe(
                partner_ids=[record.partner_id.id], subtype_ids=[subtype_id.id]
            )
            record.with_context(skip_modification_mail=True).write(
                {
                    "modification_ids": [
                        (0, 0, {"date": date_start, "description": _("Contract start")})
                    ]
                }
            )

    @api.model
    def _modification_mail_send(self):
        for record in self:
            modification_ids_not_sent = record.modification_ids.filtered(
                lambda x: not x.sent
            )
            if modification_ids_not_sent:
                if not self.env.context.get("skip_modification_mail"):
                    record.with_context(
                        default_subtype_id=self.env.ref(
                            "contract.mail_message_subtype_contract_modification"
                        ).id,
                    ).message_post_with_template(
                        self.env.ref("contract.mail_template_contract_modification").id,
                        email_layout_xmlid="contract.template_contract_modification",
                    )
                modification_ids_not_sent.write({"sent": True})

    def _compute_access_url(self):
        for record in self:
            record.access_url = "/my/contracts/{}".format(record.id)

    def action_preview(self):
        """Invoked when 'Preview' button in contract form view is clicked."""
        self.ensure_one()
        return {
            "type": "ir.actions.act_url",
            "target": "self",
            "url": self.get_portal_url(),
        }

    def _inverse_partner_id(self):
        for rec in self:
            if not rec.invoice_partner_id:
                rec.invoice_partner_id = rec.partner_id.address_get(["invoice"])[
                    "invoice"
                ]

    def _get_related_invoices(self):
        self.ensure_one()

        invoices = (
            self.env["account.move.line"]
            .search(
                [
                    (
                        "contract_line_id",
                        "in",
                        self.contract_line_ids.ids,
                    )
                ]
            )
            .mapped("move_id")
        )
        # we are forced to always search for this for not losing possible <=v11
        # generated invoices
        invoices |= self.env["account.move"].search([("old_contract_id", "=", self.id)])
        return invoices

    def _get_computed_currency(self):
        """Helper method for returning the theoretical computed currency."""
        self.ensure_one()
        currency = self.env["res.currency"]
        if any(self.contract_line_ids.mapped("automatic_price")):
            # Use pricelist currency
            currency = (
                    self.pricelist_id.currency_id
                    or self.partner_id.with_company(
                self.company_id
            ).property_product_pricelist.currency_id
            )
        return currency or self.journal_id.currency_id or self.company_id.currency_id

    @api.depends(
        "manual_currency_id",
        "pricelist_id",
        "partner_id",
        "journal_id",
        "company_id",
    )
    def _compute_currency_id(self):
        for rec in self:
            if rec.manual_currency_id:
                rec.currency_id = rec.manual_currency_id
            else:
                rec.currency_id = rec._get_computed_currency()

    def _inverse_currency_id(self):
        """If the currency is different from the computed one, then save it
        in the manual field.
        """
        for rec in self:
            if rec._get_computed_currency() != rec.currency_id:
                rec.manual_currency_id = rec.currency_id
            else:
                rec.manual_currency_id = False

    def _compute_invoice_count(self):
        for rec in self:
            rec.invoice_count = len(rec._get_related_invoices())

    def action_show_invoices(self):
        self.ensure_one()
        tree_view = self.env.ref("account.view_invoice_tree", raise_if_not_found=False)
        form_view = self.env.ref("account.view_move_form", raise_if_not_found=False)
        ctx = dict(self.env.context)
        if ctx.get("default_contract_type"):
            ctx["default_move_type"] = (
                "out_invoice"
                if ctx.get("default_contract_type") == "sale"
                else "in_invoice"
            )
        action = {
            "type": "ir.actions.act_window",
            "name": "Invoices",
            "res_model": "account.move",
            "view_mode": "tree,kanban,form,calendar,pivot,graph,activity",
            "domain": [("id", "in", self._get_related_invoices().ids)],
            "context": ctx,
        }
        if tree_view and form_view:
            action["views"] = [(tree_view.id, "tree"), (form_view.id, "form")]
        return action

    @api.depends("contract_line_ids.date_end")
    def _compute_date_end(self):
        for contract in self:
            contract.date_end = False
            date_end = contract.contract_line_ids.mapped("date_end")
            if date_end and all(date_end):
                contract.date_end = max(date_end)

    # pylint: disable=missing-return
    @api.depends(
        "contract_line_ids.recurring_next_date",
        "contract_line_ids.is_canceled",
    )
    def _compute_recurring_next_date(self):
        for contract in self:
            recurring_next_date = contract.contract_line_ids.filtered(
                lambda l: (
                        l.recurring_next_date
                        and not l.is_canceled
                        and (not l.display_type or l.is_recurring_note)
                )
            ).mapped("recurring_next_date")
            # we give priority to computation from date_start if modified
            if (
                    contract._origin
                    and contract._origin.date_start != contract.date_start
                    or not recurring_next_date
            ):
                super(ContractContract, contract)._compute_recurring_next_date()
            else:
                contract.recurring_next_date = min(recurring_next_date)

    @api.depends("contract_line_ids.create_invoice_visibility")
    def _compute_create_invoice_visibility(self):
        for contract in self:
            contract.create_invoice_visibility = any(
                contract.contract_line_ids.mapped("create_invoice_visibility")
            )

    @api.onchange("contract_template_id")
    def _onchange_contract_template_id(self):
        """Update the contract fields with that of the template.

        Take special consideration with the `contract_line_ids`,
        which must be created using the data from the contract lines. Cascade
        deletion ensures that any errant lines that are created are also
        deleted.
        """
        contract_template_id = self.contract_template_id
        if not contract_template_id:
            return
        for field_name, field in contract_template_id._fields.items():
            if field.name == "contract_line_ids":
                lines = self._convert_contract_lines(contract_template_id)
                self.contract_line_ids += lines
            elif not any(
                    (
                            field.compute,
                            field.related,
                            field.automatic,
                            field.readonly,
                            field.company_dependent,
                            field.name in self.NO_SYNC,
                    )
            ):
                if self.contract_template_id[field_name]:
                    self[field_name] = self.contract_template_id[field_name]

    @api.onchange("partner_id", "company_id")
    def _onchange_partner_id(self):
        partner = (
            self.partner_id
            if not self.company_id
            else self.partner_id.with_company(self.company_id)
        )
        self.pricelist_id = partner.property_product_pricelist.id
        self.fiscal_position_id = partner.env[
            "account.fiscal.position"
        ].get_fiscal_position(partner.id)
        if self.contract_type == "purchase":
            self.payment_term_id = partner.property_supplier_payment_term_id
        else:
            self.payment_term_id = partner.property_payment_term_id
        self.invoice_partner_id = self.partner_id.address_get(["invoice"])["invoice"]

    def _convert_contract_lines(self, contract):
        self.ensure_one()
        new_lines = self.env["contract.line"]
        contract_line_model = self.env["contract.line"]
        for contract_line in contract.contract_line_ids:
            vals = contract_line._convert_to_write(contract_line.read()[0])
            # Remove template link field
            vals.pop("contract_template_id", False)
            vals["date_start"] = fields.Date.context_today(contract_line)
            vals["recurring_next_date"] = fields.Date.context_today(contract_line)
            new_lines += contract_line_model.new(vals)
        new_lines._onchange_is_auto_renew()
        return new_lines

    def _prepare_invoice(self, date_invoice, journal=None):
        """Prepare in a Form the values for the generated invoice record.

        :return: A tuple with the vals dictionary and the Form with the
          preloaded values for being used in lines.
        """
        self.ensure_one()
        if not journal:
            journal = (
                self.journal_id
                if self.journal_id.type == self.contract_type
                else self.env["account.journal"].search(
                    [
                        ("type", "=", self.contract_type),
                        ("company_id", "=", self.company_id.id),
                    ],
                    limit=1,
                )
            )
        if not journal:
            raise ValidationError(
                _(
                    "Please define a %(contract_type)s journal "
                    "for the company '%(company)s'."
                )
                % {
                    "contract_type": self.contract_type,
                    "company": self.company_id.name or "",
                }
            )
        invoice_type = "out_invoice"
        if self.contract_type == "purchase":
            invoice_type = "in_invoice"
        move_form = Form(
            self.env["account.move"]
            .with_company(self.company_id)
            .with_context(default_move_type=invoice_type, default_name="/"),
            view="contract.view_account_move_contract_helper_form",
        )
        move_form.partner_id = self.invoice_partner_id
        move_form.journal_id = journal
        move_form.currency_id = self.currency_id
        move_form.invoice_date = date_invoice
        if self.payment_term_id:
            move_form.invoice_payment_term_id = self.payment_term_id
        if self.fiscal_position_id:
            move_form.fiscal_position_id = self.fiscal_position_id
        if invoice_type == "out_invoice" and self.user_id:
            move_form.invoice_user_id = self.user_id
        invoice_vals = move_form._values_to_save(all_fields=True)
        invoice_vals.update(
            {
                "ref": self.code,
                "invoice_origin": self.name,
            }
        )
        return invoice_vals, move_form

    def action_contract_send(self):
        self.ensure_one()
        template = self.env.ref("contract.email_contract_template", False)
        compose_form = self.env.ref("mail.email_compose_message_wizard_form")
        ctx = dict(
            default_model="contract.contract",
            default_res_id=self.id,
            default_use_template=bool(template),
            default_template_id=template and template.id or False,
            default_composition_mode="comment",
        )
        return {
            "name": _("Compose Email"),
            "type": "ir.actions.act_window",
            "view_mode": "form",
            "res_model": "mail.compose.message",
            "views": [(compose_form.id, "form")],
            "view_id": compose_form.id,
            "target": "new",
            "context": ctx,
        }

    def create_insurance_policy(self):
        self.ensure_one()
        insurance_policy_obj = self.env['insurance.policy'].sudo()
        val = {}
        for rec in self:
            if rec.partner_id:
                val['customer_id'] = rec.partner_id
            if rec.date_start:
                val['date_from'] = rec.date_start
            if rec.date_end:
                val['date_to'] = rec.date_end
            if rec.contract_value:
                val['amount'] = rec.contract_value
            if rec.code:
                rec['contract_no'] = rec.code
            val['contract_id'] = self.id
        if val:
            insurance_policy_obj.create(val)

    def create_letters_of_guarantee(self):
        self.ensure_one()
        text = False
        if self.tender_purpose and self.tender_number:
            text = self.tender_purpose + " - " + self.tender_number
        elif self.tender_purpose and not self.tender_number:
            text = self.tender_purpose
        elif not self.tender_purpose and self.tender_number:
            text = self.tender_number
        else:
            text = False
        self.env['letters.of.guarantee.request'].create({
            'beneficiary': self.partner_id.id,
            'letter_purpose': text,
            'letter_value': self.contract_value,
            'project_id': self.project_id.id if self.project_id else False,
        })
        # letters_of_guarantee_obj = self.env['letters.of.guarantee'].sudo()
        # val = {}
        # for rec in self:
        #     if rec.partner_id:
        #         val['beneficiary'] = rec.partner_id.id
        #
        # if val:
        #     val['customer_id'] = self.id
        #     letters_of_guarantee_obj.create(val)

    def action_show_insurance_policy(self):
        policy_id = self.env['insurance.policy'].sudo()
        views = [(False, 'tree'), (False, 'form')]
        for rec in self:
            return {
                'type': 'ir.actions.act_window',
                'res_model': 'insurance.policy',
                'view_mode': 'form,tree',
                'view_type': 'form',
                'res_id': policy_id.id,
                'views': views,
                'target': 'current',
                'domain': [('contract_id', '=', rec.id)],
            }

    def action_show_letters_of_guarantee(self):
        order_id = self.env['letters.of.guarantee'].sudo()
        views = [(False, 'tree'), (False, 'form')]
        for rec in self:
            return {
                'type': 'ir.actions.act_window',
                'res_model': 'letters.of.guarantee',
                'view_mode': 'form,tree',
                'view_type': 'form',
                'res_id': order_id.id,
                'views': views,
                'target': 'current',
                'domain': [('customer_id', '=', rec.id)],
            }

    def action_show_tender_request(self):
        for rec in self:
            domain = [('id', '=', rec.tender_request_id.id)]
            view_tree = {
                'name': 'Tender Request',
                'view_type': 'form',
                'view_mode': 'tree,form',
                'res_model': 'tender.request',
                'type': 'ir.actions.act_window',
                'domain': domain,
            }
            return view_tree

    @api.model
    def _get_contracts_to_invoice_domain(self, date_ref=None):
        """
        This method builds the domain to use to find all
        contracts (contract.contract) to invoice.
        :param date_ref: optional reference date to use instead of today
        :return: list (domain) usable on contract.contract
        """
        domain = []
        if not date_ref:
            date_ref = fields.Date.context_today(self)
        domain.extend([("recurring_next_date", "<=", date_ref)])
        return domain

    def _get_lines_to_invoice(self, date_ref):
        """
        This method fetches and returns the lines to invoice on the contract
        (self), based on the given date.
        :param date_ref: date used as reference date to find lines to invoice
        :return: contract lines (contract.line recordset)
        """
        self.ensure_one()

        def can_be_invoiced(contract_line):
            return (
                    not contract_line.is_canceled
                    and contract_line.recurring_next_date
                    and contract_line.recurring_next_date <= date_ref
            )

        lines2invoice = previous = self.env["contract.line"]
        current_section = current_note = False
        for line in self.contract_line_ids:
            if line.display_type == "line_section":
                current_section = line
            elif line.display_type == "line_note" and not line.is_recurring_note:
                if line.note_invoicing_mode == "with_previous_line":
                    if previous in lines2invoice:
                        lines2invoice |= line
                    current_note = False
                elif line.note_invoicing_mode == "with_next_line":
                    current_note = line
            elif line.is_recurring_note or not line.display_type:
                if can_be_invoiced(line):
                    if current_section:
                        lines2invoice |= current_section
                        current_section = False
                    if current_note:
                        lines2invoice |= current_note
                    lines2invoice |= line
                    current_note = False
            previous = line
        return lines2invoice.sorted()

    def _prepare_recurring_invoices_values(self, date_ref=False):
        """
        This method builds the list of invoices values to create, based on
        the lines to invoice of the contracts in self.
        !!! The date of next invoice (recurring_next_date) is updated here !!!
        :return: list of dictionaries (invoices values)
        """
        invoices_values = []
        for contract in self:
            if not date_ref:
                date_ref = contract.recurring_next_date
            if not date_ref:
                # this use case is possible when recurring_create_invoice is
                # called for a finished contract
                continue
            contract_lines = contract._get_lines_to_invoice(date_ref)
            if not contract_lines:
                continue
            invoice_vals, move_form = contract._prepare_invoice(date_ref)
            invoice_vals["invoice_line_ids"] = []
            for line in contract_lines:
                invoice_line_vals = line._prepare_invoice_line(move_form=move_form)
                if invoice_line_vals:
                    # Allow extension modules to return an empty dictionary for
                    # nullifying line. We should then cleanup certain values.
                    del invoice_line_vals["company_id"]
                    del invoice_line_vals["company_currency_id"]
                    invoice_vals["invoice_line_ids"].append((0, 0, invoice_line_vals))
            invoices_values.append(invoice_vals)
            # Force the recomputation of journal items
            del invoice_vals["line_ids"]
            contract_lines._update_recurring_next_date()
        return invoices_values

    def recurring_create_invoice(self):
        """
        This method triggers the creation of the next invoices of the contracts
        even if their next invoicing date is in the future.
        """
        invoices = self._recurring_create_invoice()
        for invoice in invoices:
            self.message_post(
                body=_(
                    "Contract manually invoiced: "
                    "<a"
                    '    href="#" data-oe-model="%(model_name)s" '
                    '    data-oe-id="%(rec_id)s"'
                    ">Invoice"
                    "</a>"
                )
                     % {
                         "model_name": invoice._name,
                         "rec_id": invoice.id,
                     }
            )
        return invoices

    @api.model
    def _invoice_followers(self, invoices):
        invoice_create_subtype = self.env.ref(
            "contract.mail_message_subtype_invoice_created"
        )
        for item in self:
            partner_ids = item.message_follower_ids.filtered(
                lambda x: invoice_create_subtype in x.subtype_ids
            ).mapped("partner_id")
            if partner_ids:
                (invoices & item._get_related_invoices()).message_subscribe(
                    partner_ids=partner_ids.ids
                )

    @api.model
    def _add_contract_origin(self, invoices):
        for item in self:
            for move in invoices & item._get_related_invoices():
                move.message_post(
                    body=(
                        _(
                            (
                                "%(msg)s by contract <a href=# data-oe-model=contract.contract"
                                " data-oe-id=%(contract_id)d>%(contract)s</a>."
                            ),
                            msg=move._creation_message(),
                            contract_id=item.id,
                            contract=item.display_name,
                        )
                    )
                )

    def _recurring_create_invoice(self, date_ref=False):
        invoices_values = self._prepare_recurring_invoices_values(date_ref)
        moves = self.env["account.move"].create(invoices_values)
        self._add_contract_origin(moves)
        self._invoice_followers(moves)
        self._compute_recurring_next_date()
        return moves

    @api.model
    def _get_recurring_create_func(self, create_type="invoice"):
        """
        Allows to retrieve the recurring create function depending
        on generate_type attribute
        """
        if create_type == "invoice":
            return self.__class__._recurring_create_invoice

    @api.model
    def _cron_recurring_create(self, date_ref=False, create_type="invoice"):
        """
        The cron function in order to create recurrent documents
        from contracts.
        """
        _recurring_create_func = self._get_recurring_create_func(
            create_type=create_type
        )
        if not date_ref:
            date_ref = fields.Date.context_today(self)
        domain = self._get_contracts_to_invoice_domain(date_ref)
        domain = expression.AND(
            [
                domain,
                [("generation_type", "=", create_type)],
            ]
        )
        contracts = self.search(domain)
        companies = set(contracts.mapped("company_id"))
        # Invoice by companies, so assignation emails get correct context
        for company in companies:
            contracts_to_invoice = contracts.filtered(
                lambda c: c.company_id == company
                          and (not c.date_end or c.recurring_next_date <= c.date_end)
            ).with_company(company)
            _recurring_create_func(contracts_to_invoice, date_ref)
        return True

    @api.model
    def cron_recurring_create_invoice(self, date_ref=None):
        return self._cron_recurring_create(date_ref, create_type="invoice")

    def action_terminate_contract(self):
        self.ensure_one()
        context = {"default_contract_id": self.id}
        return {
            "type": "ir.actions.act_window",
            "name": _("Terminate Contract"),
            "res_model": "contract.contract.terminate",
            "view_mode": "form",
            "target": "new",
            "context": context,
        }

    def _terminate_contract(
            self, terminate_reason_id, terminate_comment, terminate_date
    ):
        self.ensure_one()
        if not self.env.user.has_group("contract.can_terminate_contract"):
            raise UserError(_("You are not allowed to terminate contracts."))
        self.contract_line_ids.filtered("is_stop_allowed").stop(terminate_date)
        self.write(
            {
                "is_terminated": True,
                "terminate_reason_id": terminate_reason_id.id,
                "terminate_comment": terminate_comment,
                "terminate_date": terminate_date,
            }
        )
        return True

    def action_cancel_contract_termination(self):
        self.ensure_one()
        self.write(
            {
                "is_terminated": False,
                "terminate_reason_id": False,
                "terminate_comment": False,
                "terminate_date": False,
            }
        )

    @api.depends('contract_line_ids')
    def x_compute_total_contract_achievement(self):
        total_contract = 0.0
        total_invoice = 0.0
        for rec in self:
            for line in rec.contract_line_ids:
                total_invoice += line.invoice_subtotal
                total_contract += line.price_subtotal
            if total_contract and total_invoice:
                rec.total_achievement = (total_contract / total_invoice) * 100
            else:
                rec.total_achievement = 0.0

    def _compute_total_invoice(self):
        for rec in self:
            total = 0.0
            invoices = rec._get_related_invoices()
            if invoices:
                for inv in invoices:
                    if inv.state == 'posted':
                        total += inv.amount_total_signed
            rec.total_invoice = total

    @api.depends('contract_value')
    def _compute_total_remaining(self):
        # for rec in self:
        #     total = 0.0
        #     invoices = rec._get_related_invoices()
        #     if invoices:
        #         for inv in invoices:
        #             if inv.state == 'posted':
        #                 total += inv.amount_residual
        #     rec.total_remaining = total
        for rec in self:
            total = 0.0
            total += rec.contract_value - rec.total_invoice
            rec.total_remaining = total

    # def _compute_total_paid(self):
    #     for rec in self:
    #         total_due_amount = 0.0
    #         invoices = rec._get_related_invoices()
    #         if invoices:
    #             for inv in invoices:
    #                 if inv.state == 'posted':
    #                     total_due_amount += inv.amount_residual
    #     for rec in self:
    #         total = 0.0
    #         rec.total_paid = rec.total_invoice - total_due_amount
    #         rec.total_paid = total

    def _compute_receivable_amount(self):
        for rec in self:
            total = 0.0
            invoices = rec._get_related_invoices()
            if invoices:
                for inv in invoices:
                    if inv.state == 'posted':
                        total += inv.amount_residual
            rec.receivable_amount = total

    def _compute_total_paid(self):
        for rec in self:
            total = 0.0
            rec.total_paid = rec.total_invoice - rec.receivable_amount

    def _compute_total_contract_achievement(self):
        # for rec in self:
        #     total = 0.0
        #     if rec.total_paid and rec.contract_value:
        #         total = (rec.total_paid / rec.contract_value) * 100
        #     rec.total_achievement = total
        total = 0.0
        for rec in self:
            if rec.total_invoice and rec.contract_value:
                total = (rec.total_invoice / rec.contract_value) * 100
            else:
                total = 0.0

            rec.total_achievement = total


class ContractExtensionDateLine(models.Model):
    _name = 'contract.extension.line'
    _description = 'Extension Date Line'

    name = fields.Char(string="name")
    new_extension_date = fields.Date(string="New Extension Date")
    check = fields.Boolean(string="Check")
    contract_id = fields.Many2one('contract.contract', string="Insurance Policy")

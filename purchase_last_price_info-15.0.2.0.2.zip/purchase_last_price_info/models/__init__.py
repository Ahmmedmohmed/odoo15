from . import product_product
from . import product_template

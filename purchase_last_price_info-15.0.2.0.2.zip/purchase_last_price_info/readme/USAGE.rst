In order to use this module, go to:

* Products -> Tab Purchase (see screenshot)

.. image:: ../static/description/purchase_last_price.png
   :alt: Purchase Last Price Info
   :width: 400 px

This module adds the last purchase info of the product.

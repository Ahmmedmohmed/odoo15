* Alfredo de la Fuente <alfredodelafuente@avanzosc.es>
* Oihane Crucelaegui <oihanecrucelaegi@avanzosc.es>
* Ana Juaristi <anajuaristi@avanzosc.es>
* Carlos Lopez Mite <celm1990@hotmail.com>
* Adria Gil Sorribes <adria.gil@forgeflow.com>
* Lois Rilo <lois.rilo@forgeflow.com>
* Rattapong Chokmasermkul <rattapongc@ecosoft.co.th>
* Vishnu Vanneri <vanneri.odoodev@gmail.com>

* `Tecnativa <https://www.tecnativa.com>`_:

  * Víctor Martínez
  * Pedro M. Baeza

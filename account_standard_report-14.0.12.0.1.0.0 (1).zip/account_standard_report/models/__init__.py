# -*- coding: utf-8 -*-

from . import account
from . import res_currency
from . import account_standard_report_template

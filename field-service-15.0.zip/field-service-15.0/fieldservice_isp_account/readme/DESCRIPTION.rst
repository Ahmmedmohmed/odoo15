This module adds the ability to track employee time and contractor
costs for Field Service Orders. It also adds functionality to create
a customer invoice and a vendor bill when a Field Service Order is
completed.

This module allows you to link the Field Service App to the Purchases App.

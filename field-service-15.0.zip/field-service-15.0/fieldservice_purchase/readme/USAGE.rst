To use this module, you need to:

* Go to Purchases > Purchase > Vendor Pricelist
* Select or create a Vendor Pricelist and set the Vendor to an FSM Worker
* Go to Field Service > Master Data > Workers
* Open the Worker that was selected on your Vendor Pricelist
* Click on the smart button "Pricelists" to see the list of related Vendor Pricelists

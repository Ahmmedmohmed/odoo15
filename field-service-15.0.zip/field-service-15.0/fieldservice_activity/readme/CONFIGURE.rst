To use this module, you need to:

* Go to Field Service > Configuration > Manage Order Activities

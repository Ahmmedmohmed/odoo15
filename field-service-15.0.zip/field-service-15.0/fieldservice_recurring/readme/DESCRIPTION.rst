This module allows you to manage your recurring field service work orders

Recurring settings are configured via the FSM Frequency model. Multiple
FSM Frequency can be combined on a FSM Frequency Rule Set which enables
highly configurable recurring rules calculated using the dateutil rrule
python library.

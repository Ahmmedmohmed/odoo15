To use this module, you need to:

#. Go to Settings > Users & Companies
#. Define your territories, branches, districts and regions with their respective manager.

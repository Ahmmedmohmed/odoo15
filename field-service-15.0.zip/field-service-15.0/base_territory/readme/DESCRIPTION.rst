This module allows you to define territories, branches, districts and regions to be used for Field Service operations or Sales.

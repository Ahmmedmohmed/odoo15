To use this module, you need to:

* Create a new service order
* Under the Inventory tab, select the warehouse, the delivery method and add
  products with quantity
* Confirm the order to create the delivery orders with the selected method

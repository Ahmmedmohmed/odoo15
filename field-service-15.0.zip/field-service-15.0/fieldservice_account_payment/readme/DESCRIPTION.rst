This module allows the worker to accept payments during his work at the location.

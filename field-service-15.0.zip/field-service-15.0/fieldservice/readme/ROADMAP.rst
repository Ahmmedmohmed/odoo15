The roadmap of the Field Service application is documented on
`Github <https://github.com/OCA/field-service/issues/1>`_.

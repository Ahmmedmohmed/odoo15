A completed stock move for a properly configured Product on a configured
stock Operation Type will automatically create a field service equipment.

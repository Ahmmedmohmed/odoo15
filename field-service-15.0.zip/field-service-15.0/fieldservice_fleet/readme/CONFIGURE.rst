Upon installation, any existing FSM Vehicles will have Fleet vehicles created for them.

Go to Fleet and review the vehicles created from the existing FSM vehicles

* Update the vehicle model as needed
* Update the odometer unit which is set to kilometers by default

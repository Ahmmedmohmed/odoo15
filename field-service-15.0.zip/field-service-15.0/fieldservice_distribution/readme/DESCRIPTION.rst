This module allows you to manage your distribution network (of water,
electricity, gaz, telephone, bandwidth) by setting the distribution parent on a
field service location.

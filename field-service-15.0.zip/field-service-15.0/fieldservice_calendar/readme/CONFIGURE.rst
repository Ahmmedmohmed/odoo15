A "calendar" user should be set on FSM Team. Events will be added to his calendar.
Then the FSM Order' person_id (worker) will be an attendee of the calendar's event (Meeting).

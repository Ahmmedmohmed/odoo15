No configuration is needed.

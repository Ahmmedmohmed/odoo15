The stage of an order is used to monitor its progress. Stages can be configured
based on your company's specific business needs. A basic set of order stages
comes pre-configured for use.

#. Go to *Field Service > Configuration > Stages*
#. Create or edit a stage
#. Set the name for the stage.
#. Set the sequence order for the stage.
#. Select *Order* type to apply this stage to your orders.
#. Additonally, you can set a color for the stage.

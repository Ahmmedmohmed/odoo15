To install Field Service and have the mapping features,
you need to install fieldservice_stock and mrp_repair

Please refer to the installation instructions available at:
https://github.com/OCA/field-service/tree/12.0/fieldservice_stock

Odoo Repair App does not support Field Service operations for products outside the company facilities.
On the other hand, the Field Service App does not support part management (add, update, remove) of an equipment.

This module allows you to repair FSM equipments and manage their parts: add, update/replace, remove.

First install partner_multi_relation from OCA/partner-contact and then
install the fieldservice module. After these are installed you can install
this module.

Please refer to the installation instructions available at:
https://github.com/OCA/field-service/tree/11.0/fieldservice_partner_multi_relation

Partner Multi Relations does not support FSM Locations as a left or right
partner_id, only Organisation and Person

This module allows you to connect partner_multi_relations with FSM Locations and
comes with a predifined list of relation types for the user to use.

To use this module, you need to:

* Go to Contacts > Relations
* Set a relation of your choosing using your new type

# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).

from . import res_partner_relation_type
from . import res_partner
from . import fsm_location
from . import res_partner_relation_all

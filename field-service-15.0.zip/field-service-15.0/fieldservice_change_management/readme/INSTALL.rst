Either install the module from Apps or via the Field Service settings.

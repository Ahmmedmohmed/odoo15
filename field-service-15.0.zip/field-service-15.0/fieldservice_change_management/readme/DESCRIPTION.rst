This module adds change logs to the Field Service Location. Change logs are
used to track changes at a location. Example could be structural changes or
configuration changes.

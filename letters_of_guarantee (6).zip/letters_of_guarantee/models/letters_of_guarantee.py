from odoo import fields, models, api
from datetime import timedelta


class LettersOfGuarantee(models.Model):
    _name = 'letters.of.guarantee'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    bank = fields.Char('Bank')
    letter_type = fields.Selection([('primary', 'ابتدائي'), ('ultimate', 'نهائي'), ('advance_payment', 'دفعة مقدمة')],
                                   string="نوع الخطاب")
    beneficiary = fields.Many2one('res.partner')
    customer_id = fields.Many2one('contract.contract', string="Contract")
    letter_number = fields.Char('Letter Number')
    release_date = fields.Date('Release Date')
    letter_length = fields.Integer('مدة الخطاب')
    purpose = fields.Char("الغرض من الاصدار")
    expiry_date = fields.Date(compute='_compute_expiry_date', string='Expiry Date')
    extend = fields.Integer(default=0, string='فترة التمديد')
    project_id = fields.Many2one('project.project', 'Project')
    letter_value = fields.Float('Letter Value')
    insurance_value = fields.Float(compute='_compute_insurance_value', string='قيمة التأمين')
    percentage = fields.Float('النسبة')
    letter_state = fields.Selection([('in_progress', 'In Progress'), ('expired', 'Expired')], string='Letter State')
    bank_response_date = fields.Date('Bank Response Date')
    bank_response = fields.Char('Bank Response')
    state = fields.Selection([('returned', 'مردود'), ('extended', 'ممتد')])
    request_id = fields.Many2one('letters.of.guarantee.request')

    @api.depends('letter_value', 'percentage')
    def _compute_insurance_value(self):
        for rec in self:
            rec.insurance_value = rec.percentage / 100 * rec.letter_value

    @api.depends('release_date', 'extend', 'letter_length')
    def _compute_expiry_date(self):
        for record in self:
            if record.release_date and record.letter_length:
                length = record.letter_length + record.extend
                record.expiry_date = record.release_date + timedelta(days=length)
            else:
                record.expiry_date = False

    def action_return(self):
        self.state = 'returned'

    def action_extend(self):
        self.state = 'extended'


class Project(models.Model):
    _inherit = 'project.project'

    def action_open_letters_of_guarantee(self):
        letters_of_guarantee = self.env['letters.of.guarantee'].search([('project_id', '=', self.id)])
        action = self.env.ref('letters_of_guarantee.action_letters_of_guarantee').read()[0]
        action['domain'] = [('id', 'in', letters_of_guarantee.ids)]
        return action

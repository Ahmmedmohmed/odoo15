To view the timeline:

* Go to *Project > Search > Tasks* or *Project > Dashboard*.
* Click on the timeline view icon.
* You will see the tasks or projects in the new view.

The Task timeline uses the "Planned Start Date" and "Planned End Date" fields, in the
"Extra Info" tab (only visible in debug mode).

When a user is assigned, and there's no planned start date, current datetime is filled
there, and the same happens for the end one when the task is put in a done stage.

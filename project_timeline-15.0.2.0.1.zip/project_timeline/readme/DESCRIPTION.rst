This module extends the standard tasks and projects actions to add the timeline view to
them, and also adds the needed fields in the view for handling them.

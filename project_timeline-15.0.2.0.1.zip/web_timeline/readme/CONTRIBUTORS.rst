* Laurent Mignon <laurent.mignon@acsone.eu>
* Adrien Peiffer <adrien.peiffer@acsone.eu>
* Leonardo Donelli <donelli@webmonks.it>
* Adrien Didenot <adrien.didenot@horanet.com>
* Dennis Sluijk <d.sluijk@onestein.nl>
* Thong Nguyen Van <thongnv@trobz.com>
* Murtaza Mithaiwala <mmithaiwala@opensourceintegrators.com>
* Ammar Officewala <aofficewala@opensourceintegrators.com>
* `Tecnativa <https://www.tecnativa.com>`_:

  * Pedro M. Baeza
  * Alexandre Díaz
  * César A. Sánchez

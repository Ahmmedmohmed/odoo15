Define a new view displaying events in an interactive visualization chart.

The widget is based on the external library
https://visjs.github.io/vis-timeline/examples/timeline

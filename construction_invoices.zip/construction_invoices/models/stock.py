from odoo import models, fields, api, _
from odoo.exceptions import ValidationError


class StockPicking(models.Model):
    _inherit = 'stock.picking'
    project_id = fields.Many2one('construction.project', string="Project")
    picking_code = fields.Selection(related='picking_type_id.code')

    def button_validate(self):
        res = super(StockPicking, self).button_validate()
        for rec in self:
            if rec.picking_code  == 'outgoing':
                for line in rec.move_ids_without_package:
                    move_id = self.env['account.move'].search([('ref', 'ilike', rec.name +' - '+line.product_id.name)], limit=1)
                    move_id.project_id = rec.project_id.id
                    for ll in move_id.line_ids:
                        if line.product_id == ll.product_id:
                            if ll.debit >0:
                                ll.tender_id = line.tender_id.id
                                ll.break_down_id = line.break_down_id.id
                                ll.break_down_line_id = line.break_down_line_id.id
        return res


class StockMove(models.Model):
    _inherit = 'stock.move'

    project_id = fields.Many2one(comodel_name='construction.project', related="picking_id.project_id")
    tender_id = fields.Many2one('tender.line')
    break_down_id = fields.Many2one(comodel_name='break.down', string="Break Down")
    break_down_line_id = fields.Many2one(comodel_name='break.down.line', string="Break Down Line")
    wbs_id = fields.Many2one('wbs.line', 'Auto WBS' )

    @api.onchange('tender_id')
    def change_construct_tender_id(self):
        for rec in self:
            break_down_id = self.env['break.down'].search([
                ('project_id', '=', rec.project_id.id),
                ('tender_line_id', '=', rec.tender_id.id),
            ], limit=1)
            rec.break_down_id = break_down_id.id
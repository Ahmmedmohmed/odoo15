from odoo import models, fields, api, _
from odoo.exceptions import ValidationError


class AccountBankStatement(models.Model):
    _inherit = 'account.bank.statement'
    project_id = fields.Many2one('construction.project', string="Project")

    def button_post(self):
        res = super(AccountBankStatement, self).button_post()
        move_id = self.env['account.move'].search([('id', 'in', self.line_ids.move_id.ids)], limit=1)
        print("XXXXXXXXbutton_post", move_id)
        for line in move_id.line_ids:
            if line.debit > 0:
                print("XXXXXXXXXXXXXXXXXXXxx", line.account_id.name)
                line.tender_id = line.tender_id.id
                line.break_down_id = line.break_down_id.id
                line.break_down_line_id = line.break_down_line_id.id
        return res


class AccountBankStatementLine(models.Model):
    _inherit = 'account.bank.statement.line'

    project_id = fields.Many2one(related="statement_id.project_id")
    tender_id = fields.Many2one('tender.line')
    product_id = fields.Many2one('product.product')
    # wbs_id = fields.Many2one('wbs.distribution', 'Auto WBS' )
    break_down_id = fields.Many2one(comodel_name='break.down', string="Break Down")
    break_down_line_id = fields.Many2one(comodel_name='break.down.line', string="Break Down Line")
    wbs_id = fields.Many2one('wbs.line', 'Auto WBS')

    @api.onchange('tender_id')
    def change_construct_tender_id(self):
        for rec in self:
            break_down_id = self.env['break.down'].search([
                ('project_id', '=', rec.project_id.id),
                ('tender_line_id', '=', rec.tender_id.id),
            ], limit=1)
            rec.break_down_id = break_down_id.id  # wbs_id = fields.Many2one('wbs.distribution', 'Auto WBS' )

    @api.model
    def _prepare_liquidity_move_line_vals(self):
        vals = super()._prepare_liquidity_move_line_vals()
        vals['tender_id'] = self.tender_id.id
        vals['break_down_id'] = self.break_down_id.id
        vals['break_down_line_id'] = self.break_down_line_id.id
        return vals

    @api.model
    def _prepare_counterpart_move_line_vals(self, counterpart_vals, move_line=None):
        vals = super()._prepare_counterpart_move_line_vals(counterpart_vals, move_line)
        vals['tender_id'] = self.tender_id.id
        vals['break_down_id'] = self.break_down_id.id
        vals['break_down_line_id'] = self.break_down_line_id.id
        return vals

    @api.model
    def _prepare_move_line_default_vals(self, counterpart_account_id=None):
        print("NNNNNNNNNNNNNNNNNNNNNNNnew")
        res = super(AccountBankStatementLine, self)._prepare_move_line_default_vals()
        return res

    @api.model
    def create(self, vals):
        res = super(AccountBankStatementLine, self).create(vals)
        move_line = self.env['account.move.line'].search([('statement_line_id', '=', res.id)], limit=1)
        move_line.tender_id = res.tender_id.id
        move_line.break_down_id = res.break_down_id.id
        move_line.break_down_line_id = res.break_down_line_id.id
        return res

    def write(self, vals):
        res = super(AccountBankStatementLine, self).write(vals)
        if 'tender_id' in vals:
            move_line = self.env['account.move.line'].search([('statement_line_id', '=', self.id)], limit=1)
            move_line.tender_id = self.tender_id.id
        if 'break_down_id' in vals:
            move_line = self.env['account.move.line'].search([('statement_line_id', '=', self.id)], limit=1)
            move_line.break_down_id = self.break_down_id.id
        if 'break_down_line_id' in vals:
            move_line = self.env['account.move.line'].search([('statement_line_id', '=', self.id)], limit=1)
            move_line.break_down_line_id = self.break_down_line_id.id
        return res

from odoo import models, fields, api, _
from odoo.exceptions import ValidationError


class ProductTemplate(models.Model):
    _inherit = 'product.template'

    construction_type = fields.Selection(string='Construction Type', selection=[
        ('material', 'Material'),
        ('labour', 'Labour'),
        ('expenses', 'Expenses'),
        ('sub_contractor', 'Sub Contractor'),
        ('equipment', 'Equipment'),
    ])

    # @api.model
    # def create(self, vals):
    #     res = super(ProductTemplate, self).create(vals)
    #     for line in res.product_variant_ids:
    #         line.construction_type = res.construction_type
    #     return res
    #
    # def write(self, vals):
    #     res = super(ProductTemplate, self).write(vals)
    #     if 'construction_type' in vals:
    #         for line in self.product_variant_ids:
    #             if line.construction_type != vals['construction_type']:
    #                 line.construction_type = vals['construction_type']
    #     return res


class ProductProduct(models.Model):
    _inherit = 'product.product'

    construction_type = fields.Selection(string='Construction Type', related="product_tmpl_id.construction_type")

    # @api.model
    # def create(self, vals):
    #     res = super(ProductProduct, self).create(vals)
    #     if res.product_tmpl_id:
    #         res.product_tmpl_id.construction_type = res.construction_type
    #     return res
    #
    #
    # def write(self, vals):
    #     res = super(ProductProduct, self).write(vals)
    #     if 'construction_type' in vals:
    #         if self.product_tmpl_id.construction_type != vals['construction_type']:
    #             self.product_tmpl_id.construction_type = vals['construction_type']
    #     return res

from odoo import models, fields, api, _
from odoo.exceptions import ValidationError


class ResCompany(models.Model):
    _inherit = 'res.company'
    journal_id = fields.Many2one('account.journal', string="Owner Journal")
    sub_journal_id = fields.Many2one('account.journal', string="Subcontractor Journal")


class ConstructionProject(models.Model):
    _name = 'construction.project'
    _inherit = ["mail.thread", "mail.activity.mixin"]

    name = fields.Char('Name', required=True)
    partner_id = fields.Many2one('res.partner', string="Customer", required=True)
    manager_id = fields.Many2one('res.partner', string="Manager", )
    consultant_id = fields.Many2one('res.partner', string="Consultant", )
    type_id = fields.Many2one('construction.project.type', string="Type", required=False)
    date = fields.Date('Date', default=fields.Date.today)
    create_date = fields.Date('Create Date', default=fields.Date.today, readonly=1)
    tender_line_ids = fields.One2many(comodel_name='tender.line', inverse_name='construction_id')
    breakdown_ids = fields.One2many(comodel_name='break.down', inverse_name='project_id', )
    breakdown_count = fields.Integer(compute='compute_breakdown_count')
    financial_offer_id = fields.Many2one('financial.offer', string="Financial Offer")

    def create_financial_offer(self):
        if not self.breakdown_ids:
            raise ValidationError(_("create break down first"))
        x = self.breakdown_ids.filtered(lambda l: l.state == 'quotation')
        if len(x.ids) >= len(self.breakdown_ids.ids):
            offer_id = self.env['financial.offer'].create({
                'partner_id': self.partner_id.id,
                'project_id': self.id,
                'date': fields.Datetime.today(),
                'name': self.name +" Financial Offer",
            })
            for line in self.tender_line_ids:
                self.env['financial.offer.line'].create({
                    'offer_id': offer_id.id,
                    'name': line.name,
                    'tender_item_id': line.id,
                    'break_down_id': line.break_down_id.id,
                    'tender_id': line.id,
                    'description': line.description ,
                    'type': line.type,
                    'qty': line.qty,
                    'uom_id': line.uom_id.id,
                    'price': line.break_down_id.sale_price_amount,
                    'total': line.break_down_id.sale_price_amount_all,
                    'note': line.note,
                })
                self.financial_offer_id = offer_id.id
        else:
            raise ValidationError(_('All Break Down must in State Quotation'))

    @api.depends('breakdown_ids')
    def compute_breakdown_count(self):
        for rec in self:
            rec.breakdown_count = len(rec.breakdown_ids.ids)

    def create_breakdown(self):
        for line in self.tender_line_ids:
            if line.type != 'view' and not line.break_down_id:
                break_down_id = self.env['break.down'].create({
                    'project_id': line.construction_id.id,
                    'customer_id': self.partner_id.id,
                    # 'analytic_account_id': self.analytic_account_id.id,
                    'tender_line_id': line.id,
                    'code': line.name,
                    'description': line.description,
                    'name': line.name,
                    'tender_item_id': line.tender_item_id.id,
                    'uom_id': line.uom_id.id,
                    'qty': line.qty,
                    'type': line.type,
                    # 'sale_price': 0,
                    'note': line.note,
                })
                line.break_down_id = break_down_id.id

    def action_view_breakdown(self):
        action = self.env.ref("construction_invoices.breakdown_action")
        result = action.read()[0]
        result["domain"] = [("id", "in", self.breakdown_ids.ids)]
        return result

    def action_view_financial_offer(self):
        action = self.env["ir.actions.actions"]._for_xml_id("construction_invoices.financial_offer_action")
        action['views'] = [(False, 'form')]
        action['res_id'] = self.financial_offer_id.id
        return action

    # @api.model
    # def create(self, vals):
    #     res = super(ConstructionProject, self).create(vals)
    #     analytic_account_id = self.env['account.analytic.account'].create({
    #         'name': res.name,
    #         'partner_id': res.partner_id.id,
    #     })
    #     res.analytic_account_id = analytic_account_id.id
    #     return res

    @api.constrains('tender_line_ids')
    def constrains_tender_line_ids(self):
        for rec in self:
            for line in rec.tender_line_ids:
                if rec.tender_line_ids.filtered(lambda l: l.name == line.name and l != line):
                    raise ValidationError(_("Code Must be UNIQUE in Project"))


class TenderLine(models.Model):
    _name = 'tender.line'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _rec_name = 'description'

    construction_id = fields.Many2one('construction.project')
    name = fields.Char('code', required=1)
    description = fields.Char('Description', required=1)
    qty = fields.Float('Qty')
    price = fields.Float('Price')
    total = fields.Float(compute="compute_total")
    note = fields.Char()
    tender_item_id = fields.Many2one(comodel_name='tender.item', string='Tender Item')
    break_down_id = fields.Many2one('break.down')
    type = fields.Selection(string='Type', selection=[('view', 'View'), ('action', 'Action')], required=True, default='view')
    uom_id = fields.Many2one('uom.uom')
    state = fields.Selection(string='Status', selection=[('main', 'Main'), ('new', 'New')], required=True, default='main')

    def name_get(self):
        res = []
        for rec in self:
            res.append((rec.id, ("[%s] %s") % (rec.name, rec.description)))
        return res

    @api.onchange('tender_item_id')
    def change_tender_item_id(self):
        self.uom_id = self.tender_item_id.uom_id.id
        if self.type == 'view':
            self.qty = 0


    @api.depends('price', 'qty')
    def compute_total(self):
        for rec in self:
            rec.total = rec.qty * rec.price


class ConstructionProjectType(models.Model):
    _name = 'construction.project.type'
    name = fields.Char('Name', required=True)


class TenderItem(models.Model):
    _name = 'tender.item'

    name = fields.Char("Name")
    uom_id = fields.Many2one("uom.uom")
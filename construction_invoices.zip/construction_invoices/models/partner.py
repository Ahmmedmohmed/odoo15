from odoo import fields, models, api


class ModelName(models.Model):
    _inherit = 'res.partner'

    is_subcontractor = fields.Boolean('Subcontractor')

from odoo import models, fields, api, _
from odoo.exceptions import ValidationError


class QuantitySurvey(models.Model):
    _name = 'qty.survey'
    _inherit = ["mail.thread", "mail.activity.mixin"]

    name = fields.Char('Name')
    project_id = fields.Many2one('construction.project', string='project', required=True, )
    partner_id = fields.Many2one('res.partner', string='Customer', required=True, )
    date = fields.Date('Date', default=fields.Date.context_today, copy=False, required=True, )
    line_ids = fields.One2many(comodel_name='qty.survey.line', inverse_name='survey_id')

    @api.onchange('project_id')
    def _onchange_project_id(self):
        self.partner_id = self.project_id.partner_id.id

    @api.constrains('project_id')
    def constrains_project_id(self):
        last_id = self.env['qty.survey'].search([
            ('project_id', '=', self.project_id.id),
            ('partner_id', '=', self.partner_id.id),
            ('id', '!=', self.id),
        ], order='id desc', limit=1)
        print(">>>>>>>>>>>>>>>>>>..lasr",last_id)
        for rec in last_id:
            lines = []
            rec.partner_id = rec.partner_id.id
            for line in rec.line_ids:
                print(">>>>>> ", line.current_qty)
                l = self.env['qty.survey.line'].create({
                    "tender_line_id": line.tender_line_id.id,
                    "tender_item_id": line.tender_item_id.id,
                    "name": line.name,
                    "description": line.description,
                    "uom_id": line.uom_id.id,
                    "type": line.type,
                    "last_qty": line.total_qty,
                    "current_qty": 0,
                    "duration_time": line.duration_time,
                    "state": line.state,
                })
                lines.append(l.id)
            self.line_ids = [(6, 0, lines)]

    @api.model
    def create(self, vals):
        vals['name'] = self.env['ir.sequence'].next_by_code('qty.survey') or _('New')
        return super(QuantitySurvey, self).create(vals)


class QuantitySurveyLine(models.Model):
    _name = 'qty.survey.line'

    survey_id = fields.Many2one('qty.survey')
    project_id = fields.Many2one(related='survey_id.project_id')
    tender_line_id = fields.Many2one(comodel_name='tender.line', string='Tender Line')
    tender_item_id = fields.Many2one(comodel_name='tender.item', string='Tender Item')
    name = fields.Char('code',)
    description = fields.Char('Description')
    uom_id = fields.Many2one('uom.uom', readonly=True)
    type = fields.Selection(string='Type', selection=[('view', 'View'), ('action', 'Action')], required=True,
                            default='view', readonly=True)
    tender_qty = fields.Float(related="tender_line_id.qty", string="Tender Qty")
    last_qty = fields.Float('Previous Qty',readonly=1, store=1)
    current_qty = fields.Float('Current Qty')
    total_qty = fields.Float('Total Qty', compute='compute_total_qty')
    remaining_qty = fields.Float('Remaining Qty', compute="compute_remaining_qty")
    duration_time = fields.Integer('Duration Time')
    state = fields.Selection(string='Status', selection=[('main', 'Main'), ('new', 'New')], required=True,
                             default='main')
    note = fields.Char()
    cost_price = fields.Float(string="Cost Price", compute="compute_cost_price")
    cost_value = fields.Float(string="Cost Value", compute="compute_cost_price")
    sale_price = fields.Float(string="Sale Price", compute="compute_sale_price")
    sale_value = fields.Float(string="Sale Value", compute="compute_sale_price")

    @api.depends('tender_item_id', 'project_id')
    def compute_sale_price(self):
        for rec in self:
            contract_id = self.env['contract.line'].search([
                ('contract_id.type', '=', 'owner'),
                ('contract_id.construction_project_id', '=', rec.project_id.id),
                ('product_id', '=', rec.tender_line_id.id),
            ], order='id desc', limit=1)
            rec.sale_price = contract_id.price_unit if contract_id else 0
            rec.sale_value = rec.sale_price * rec.total_qty

    @api.depends('tender_item_id', 'project_id')
    def compute_cost_price(self):
        for rec in self:
            break_id = self.env['break.down'].search([
                ('project_id', '=', rec.project_id.id),
                ('tender_line_id', '=', rec.tender_line_id.id),
            ], order='id desc', limit=1)
            rec.cost_price = break_id.cost_price_total_all if break_id else 0
            rec.cost_value = break_id.cost_price_total_all * rec.total_qty if break_id else 0

    @api.depends('tender_qty', 'total_qty')
    def compute_remaining_qty(self):
        for rec in self:
            rec.remaining_qty = rec.tender_qty - rec.total_qty

    @api.depends('current_qty', 'last_qty')
    def compute_total_qty(self):
        for rec in self:
            rec.total_qty = rec.current_qty + rec.last_qty

    @api.onchange('tender_line_id')
    def change_get_tender_line(self):
        res = {}
        lines = []
        for line in self.survey_id.project_id.tender_line_ids:
            lines.append(line.id)
        res['domain'] = {'tender_line_id': [('id', 'in', lines)]}
        return res

    @api.onchange('tender_line_id')
    def change_tender_line_id(self):
        if not self.survey_id.project_id:
            raise ValidationError(_('Please Select Project First'))
        self.tender_item_id = self.tender_line_id.tender_item_id.id
        self.name = self.tender_line_id.name
        self.description = self.tender_line_id.description
        self.uom_id = self.tender_line_id.uom_id
        self.type = self.tender_line_id.type
        self.current_qty = self.tender_line_id.qty
        self.state = self.tender_line_id.state
        self.note = self.tender_line_id.note

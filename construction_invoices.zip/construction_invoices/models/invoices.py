from odoo import models, fields, api, _
from odoo.exceptions import ValidationError


class AccountPayment(models.Model):
    _inherit = 'account.payment'
    invoice_id = fields.Many2one('construction.invoice')
    subcontractor_id = fields.Many2one('res.partner', string="Subcontractor", )

    @api.onchange('invoice_id')
    def onchange_invoice_id(self):
        if self.invoice_id:
            if self.invoice_id.construction_type == 'owner':
                self.partner_id = self.invoice_id.partner_id.id
                self.payment_type = 'inbound'
                self.partner_type = 'customer'

            if self.invoice_id.construction_type == 'subcontractor':
                self.partner_id = self.invoice_id.subcontractor_id.id
                self.payment_type = 'outbound'
                self.partner_type = 'supplier'
                self.subcontractor_id = self.invoice_id.subcontractor_id.id



class ConstructionInvoice(models.Model):
    _name = 'construction.invoice'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char('Name')
    construction_type = fields.Selection(string='Type', selection=[('owner', 'Owner'), ('subcontractor', 'Subcontractor')], )
    type = fields.Selection(string='Type', selection=[
        ('1', 'Processing'),
        ('2', 'Final')
    ])
    invoice_number = fields.Char('Invoice Number')
    contract_id = fields.Many2one(comodel_name='contract', string="Contract", )
    move_id = fields.Many2one(comodel_name='account.move', string="Move")
    parent_id = fields.Many2one(comodel_name='construction.invoice', string="Parent")
    construction_project_id = fields.Many2one(related="contract_id.construction_project_id",store=1, string="Project")
    partner_id = fields.Many2one(related="contract_id.partner_id",store=1,  string="Customer")
    subcontractor_id = fields.Many2one('res.partner', related="contract_id.subcontractor_id", store=1, string="Subcontractor")
    addition_line_ids = fields.One2many(comodel_name='addition.line', inverse_name='move_id')
    deduction_line_ids = fields.One2many(comodel_name='deduction.line', inverse_name='move_id')
    invoice_line_ids = fields.One2many(comodel_name='construction.invoice.line', inverse_name='invoice_id')
    state = fields.Selection(string='State', selection=[
        ('draft', 'Draft'),
        ('confirm', 'Confirm'),
        ('journal', 'journal'),
    ], default='draft')
    payment_ids = fields.One2many(comodel_name='account.payment', inverse_name='invoice_id', copy=False)
    payment_count = fields.Integer('Count', compute="compute_payment_count")
    total_value = fields.Float(string='total')
    last_value = fields.Float(string='Last Value', store=1)
    current_value = fields.Float(string='Current Value')
    due_amount = fields.Float(string='Due Amount', compute='compute_due_amount')
    amount_paid = fields.Float(string='Amount Paid', compute='compute_paid')
    amount_difference = fields.Float(string='Amount Difference', compute='compute_paid')
    date = fields.Date(string='Date', default=fields.Date.today)
    last_invoice = fields.Boolean()
    reset_draft = fields.Boolean()
    current_addition = fields.Float(string="Current Addition", compute="get_current_addition")
    current_deduction = fields.Float(string="Current Deduction", compute="get_current_deduction")

    @api.depends('deduction_line_ids', 'addition_line_ids')
    def get_current_deduction(self):
        for rec in self:
            rec.current_deduction = sum(ded.value for ded in rec.deduction_line_ids)
            rec.current_addition = sum(add.value for add in rec.addition_line_ids)

    @api.model
    def read_group(self, domain, fields, groupby, offset=0, limit=None, orderby=False, lazy=True):
        res = super(ConstructionInvoice, self).read_group(domain, fields, groupby, offset=offset, limit=limit, orderby=orderby,
                                                 lazy=lazy)
        if 'current_deduction' in fields:
            for line in res:
                if '__domain' in line:
                    lines = self.search(line['__domain'])
                    current_addition, current_deduction = 0.0, 0.0
                    for record in lines:
                        current_deduction += record.current_deduction
                        current_addition += record.current_addition
                    line['current_deduction'] = current_deduction
                    line['current_addition'] = current_addition
        return res
    @api.constrains('deduction_line_ids')
    def constrains_deduction_line_ids(self):
        for rec in self:
            total = 0
            for line in rec.deduction_line_ids:
                if line.name.down_payment is True:
                    total += line.total_value
            if total > rec.contract_id.down_payment:
                raise ValidationError(_("Total Deduction DownPayment Must be Less than Or Equal contract DownPayment"))

    # @api.depends('name')
    # def compute_is_last_invoice(self):
    #     for rec in self:
    #         rec.last_invoice = False
    #         if rec.name:
    #             last_invoice_id = rec.env['construction.invoice'].search([
    #                 ('contract_id', '=', rec.contract_id.id),
    #                 ('construction_type', '=', rec.construction_type),
    #             ], order='id desc', limit=1)
    #             if last_invoice_id == rec:
    #                 rec.last_invoice = True
    #
    # @api.depends('name')
    # def compute_is_reset_draft(self):
    #     for rec in self:
    #         rec.reset_draft = False
    #         if rec.name:
    #             last_invoice_id = rec.env['construction.invoice'].search([
    #                 ('id', '>=', rec.id),
    #                 ('contract_id', '=', rec.contract_id.id),
    #                 ('construction_type', '=', rec.construction_type),
    #             ], order='id desc', limit=1)
    #             if rec.state != 'draft' and last_invoice_id == rec and self.env.user.has_group('construction_invoices.draft_invoice'):
    #                 rec.reset_draft = True


    @api.depends('amount_paid', 'amount_difference')
    def compute_payment_state(self):
        for rec in self:
            if rec.amount_paid == 0:
                rec.payment_state = 'not_paid'
            elif rec.amount_paid > 0 and rec.amount_paid < rec.due_amount:
                rec.payment_state = 'partial'
            elif rec.amount_paid > 0 and rec.amount_difference <= 0:
                rec.payment_state = 'paid'

    payment_state = fields.Selection(
        string='Payment State', selection=[
            ('not_paid', 'Not Paid'),
            ('partial', 'Partially Paid'),
            ('paid', 'Paid'),
        ], compute="compute_payment_state")

    @api.depends('payment_ids', 'due_amount')
    def compute_paid(self):
        for rec in self:
            total = 0
            for line in rec.payment_ids:
                if line.state == 'posted':
                    total += line.amount
            rec.amount_paid = total
            rec.amount_difference = rec.due_amount - total

    @api.depends('current_value', 'deduction_line_ids', 'addition_line_ids')
    def compute_due_amount(self):
        for rec in self:
            rec.due_amount = 0
            if 'New' not in str(rec.id):
                total_value = 0
                for line in rec.invoice_line_ids:
                    # print(line.total_qty, "    ", line.price_unit, "   ", line.percentage)
                    total_value += line.total_qty * line.price_unit * line.percentage / 100
                rec.total_value = total_value

                last_invoice_id = rec.env['construction.invoice'].search([
                    ('id', '!=', rec.id),
                    ('contract_id', '=', rec.contract_id.id),
                    ('construction_type', '=', rec.construction_type),
                    ('state', '=', 'journal'),
                ], order='id desc', limit=1)
                rec.last_value = rec.parent_id.total_value if rec.parent_id else 0
                rec.current_value = total_value - rec.last_value
                # total = total_value - rec.last_value
                total = total_value
                for add in rec.addition_line_ids:
                    total += add.value

                for ded in rec.deduction_line_ids:
                    total -= ded.value

                rec.due_amount = sum(l_in.current_value for l_in in self.invoice_line_ids ) + sum(add.value for add in self.addition_line_ids ) - sum(ded.value for ded in self.deduction_line_ids )

    @api.onchange('invoice_line_ids')
    def change_total(self):
        for rec in self:
            rec.last_value = rec.current_value = total_value = 0
            for line in rec.invoice_line_ids:
                # print(line.total_qty, "    ", line.price_unit, "   ", line.percentage)
                total_value += line.total_qty * line.price_unit * line.percentage / 100
            rec.total_value = total_value
            if 'New' not in str(rec.id):
                last_invoice_id = rec.env['construction.invoice'].search([
                    ('id', '!=', rec.id),
                    ('contract_id', '=', rec.contract_id.id),
                    ('construction_type', '=', rec.construction_type),
                    ('state', '=', 'journal'),
                ], order='id desc', limit=1)
                # print(rec)
                # print(last_invoice_id, ">>>>>>>>>>>>>>>>> last", last_invoice_id.total_value)
                rec.last_value = last_invoice_id.total_value
                rec.current_value = total_value - rec.last_value

    @api.depends('payment_ids')
    def compute_payment_count(self):
        for rec in self:
            rec.payment_count = len(rec.payment_ids.ids)

    def action_view_payment(self):
        self.ensure_one()
        action = self.env.ref("account.action_account_payments_payable").read()[0]
        action["domain"] = [("id", "in", self.payment_ids.ids)]
        if self.construction_type == 'owner':
            action['context'] = {
                'default_invoice_id': self.id,
                'default_payment_type': 'inbound',
                'default_amount': self.amount_difference,
                'default_partner_id': self.partner_id.id
            }
        elif self.construction_type == 'subcontractor':
            action['context'] = {
                'default_invoice_id': self.id,
                'default_payment_type': 'outbound',
                'default_amount': self.amount_difference,
                'default_partner_id': self.subcontractor_id.id,
                'default_partner_type': 'supplier'
            }
        return action

    @api.model
    def create(self, vals):
        if vals['construction_type'] != 'owner':
            vals['name'] = self.env['ir.sequence'].next_by_code('sub.invoice')
        elif vals['construction_type'] == 'owner':
            vals['name'] = self.env['ir.sequence'].next_by_code('owner.invoice')
        return super(ConstructionInvoice, self).create(vals)

    def action_post(self):
        print("XXXXXXXXXXXXXXXXX action_post")
        self.state = 'confirm'

    def action_draft(self):
        if self.move_id:
            self.move_id.unlink()
        if self.move_id:
            raise ValidationError(_('Remove Move first !!'))
        self.state = 'draft'

    def create_journal(self):
        if not self.invoice_line_ids:
            raise ValidationError(_('There is not invoice lines !!'))
        if not self.env.user.company_id.journal_id and self.construction_type == 'owner':
            raise ValidationError(_('please add Owner Journal in company profile'))
        if not self.env.user.company_id.sub_journal_id and self.construction_type == 'subcontractor':
            raise ValidationError(_('please add Subcontractor Journal in company profile'))
        move_id = self.env['account.move'].create({
            'journal_id': self.env.user.company_id.journal_id.id if self.construction_type == 'owner' else self.env.user.company_id.sub_journal_id.id,
            "partner_id": self.partner_id.id,
            'move_type': 'entry',
            'ref': self.name
        })
        if self.construction_type == 'owner':
            add_total = deduction_total = 0
            self.env['account.move.line'].with_context(check_move_validity=False).create({
                "move_id": move_id.id,
                "account_id": self.contract_id.account1_id.id,
                "name": 'Invoice Value',
                "debit": 0,
                "credit": self.current_value,
                "partner_id": self.partner_id.id,
            })
            for line in self.addition_line_ids:
                self.env['account.move.line'].with_context(check_move_validity=False).create({
                    "move_id": move_id.id,
                    "account_id": line.account_id.id,
                    "name": line.name.name,
                    "debit": 0,
                    "credit": line.value,
                    "partner_id": self.partner_id.id,
                })
                add_total += line.value
            for line in self.deduction_line_ids:
                self.env['account.move.line'].with_context(check_move_validity=False).create({
                    "move_id": move_id.id,
                    "account_id": line.account_id.id,
                    "name": line.name.name,
                    "credit": 0,
                    "debit": line.value,
                    "partner_id": self.partner_id.id,
                })
                deduction_total += line.value
            self.env['account.move.line'].with_context(check_move_validity=False).create({
                "move_id": move_id.id,
                "account_id": self.contract_id.account2_id.id,
                "name": 'Due Amount',
                "credit": 0,
                "debit": self.current_value + add_total - deduction_total,
                "partner_id": self.partner_id.id,
            })

        elif self.construction_type == 'subcontractor':
            add_total = deduction_total = 0
            self.env['account.move.line'].with_context(check_move_validity=False).create({
                "move_id": move_id.id,
                "account_id": self.contract_id.account1_id.id,
                "name": 'Invoice Value',
                "credit": 0,
                "debit": self.current_value,
                "partner_id": self.subcontractor_id.id,
            })
            for line in self.addition_line_ids:
                self.env['account.move.line'].with_context(check_move_validity=False).create({
                    "move_id": move_id.id,
                    "account_id": line.account_id.id,
                    "name": line.name.name,
                    "credit": 0,
                    "debit": line.value,
                    "partner_id": self.subcontractor_id.id,
                })
                add_total += line.value
            for line in self.deduction_line_ids:
                self.env['account.move.line'].with_context(check_move_validity=False).create({
                    "move_id": move_id.id,
                    "account_id": line.account_id.id,
                    "name": line.name.name,
                    "debit": 0,
                    "credit": line.value,
                    "partner_id": self.subcontractor_id.id,
                })
                deduction_total += line.value

            self.env['account.move.line'].with_context(check_move_validity=False).create({
                "move_id": move_id.id,
                "account_id": self.contract_id.account2_id.id,
                "name": "Due Amount",
                "debit": 0,
                "credit": self.current_value + add_total - deduction_total,
                "partner_id": self.subcontractor_id.id,
            })
        self.move_id = move_id.id
        self.state = 'journal'

    @api.constrains('contract_id')
    def constrains_contract_id(self):
        last_invoice_id = self.env['construction.invoice'].search([
            ('id', '!=', self.id),
            ('contract_id', '=', self.contract_id.id),
            ('construction_project_id', '=', self.contract_id.construction_project_id.id),
            ('partner_id', '=', self.partner_id.id),
            ('construction_type', '=', self.construction_type),
            ('state', '=', 'journal'),
        ], order='id desc', limit=1)
        # if not the first time
        if last_invoice_id:
            self.parent_id = last_invoice_id.id
            self.last_invoice = True
            last_invoice_id.last_invoice = False
            total_value = 0
            for inv_line in last_invoice_id.invoice_line_ids:
                if inv_line.product_id:
                    lines = []
                    wbs_distribution_ids = self.env['wbs.distribution'].search([
                        ('project_id', '=', last_invoice_id.construction_project_id.id),
                        ('partner_id', '=', last_invoice_id.partner_id.id),
                    ])
                    for wbs in wbs_distribution_ids:
                        for line in wbs.line_ids:
                            if line.tender_id == inv_line.product_id:
                                lines.append(line.wbs_line_id.id)
                    ln = self.env['construction.invoice.line'].create({
                        'invoice_id': self.id,
                        # 'account_id': inv_line.account_id.id,
                        'wbs_lines_ids': [(6, 0, lines)],
                        'product_id': inv_line.product_id.id,
                        'contract_qty': inv_line.contract_qty,
                        'last_qty': inv_line.total_qty,
                        'quantity': 0,
                        'qs_qty': inv_line.qs_qty,
                        'wbs_line_id': inv_line.wbs_line_id.id,
                        'percentage': inv_line.percentage,
                        'total_qty': inv_line.total_qty,
                        'price_unit': inv_line.price_unit,
                        'last_value': inv_line.total_value,
                    })
                    total_value += inv_line.total_qty * inv_line.price_unit * inv_line.percentage
                    ln.change_product_id()
            self.last_value = last_invoice_id.total_value

            for add in last_invoice_id.addition_line_ids:
                self.env['addition.line'].create({
                    'move_id': self.id,
                    'name': add.name.id,
                    'account_id': add.account_id.id,
                    'percentage': add.percentage,
                    'down_payment': add.down_payment,
                    'percentage_amount': add.percentage_amount if add.percentage is True else 0,
                    'last_value': add.total_value,
                    'value': 0,
                    'total_value': 0,
                })
            for ded in last_invoice_id.deduction_line_ids:
                print("LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL ", ded.total_value)
                self.env['deduction.line'].create({
                    'move_id': self.id,
                    'name': ded.name.id,
                    'account_id': ded.account_id.id,
                    'percentage': ded.percentage,
                    'down_payment': ded.down_payment,
                    'percentage_amount': ded.percentage_amount if ded.percentage is True else 0,
                    'last_value': ded.total_value,
                    'value': 0,
                    'total_value': 0,
                })

        else:
            # for invoice_line in self.invoice_line_ids:
            #     invoice_line.unlink()
            # for line in self.contract_id.line_ids:
            #     ln = self.env['construction.invoice.line'].create({
            #         'invoice_id': self.id,
            #         # 'account_id': line.product_id.property_account_income_id.id if line.product_id.property_account_income_id else
            #         # line.product_id.categ_id.property_account_income_categ_id.id,
            #         'product_id': line.product_id.id,
            #         'last_qty': 0,
            #         'quantity': line.quantity,
            #         'total_qty': line.quantity,
            #         'price_unit': line.price_unit,
            #     })
            for a in self.addition_line_ids:
                a.unlink()
            for add in self.contract_id.addition_line_ids:
                self.env['addition.line'].create({
                    'move_id': self.id,
                    'name': add.name.id,
                    'account_id': add.account_id.id,
                    'percentage': add.percentage,
                    'percentage_amount': add.percentage_amount,
                    'last_value': 0,
                    'value': add.value,
                    'total_value': add.percentage_amount
                    # if add.percentage is False else  add.contract_id.total * add.percentage_amount / 100,
                })

            for d in self.deduction_line_ids:
                d.unlink()
            for ded in self.contract_id.deduction_line_ids:
                self.env['deduction.line'].create({
                    'move_id': self.id,
                    'account_id': ded.account_id.id,
                    'name': ded.name.id,
                    'percentage': ded.percentage,
                    'percentage_amount': ded.percentage_amount,
                    'last_value': 0,
                    'value': ded.contract_total_value,
                    'total_value': ded.percentage_amount
                    # if add.percentage is False else add.contract_id.total * add.percentage_amount / 100,
                })


class ConstructionInvoiceLine(models.Model):
    _name = 'construction.invoice.line'

    invoice_id = fields.Many2one('construction.invoice')
    project_id = fields.Many2one('construction.project', related='invoice_id.construction_project_id')
    construction_type = fields.Selection(string='Type', related='invoice_id.construction_type')
    name = fields.Char('Description')
    contract_line_id = fields.Many2one('contract.line')
    product_id = fields.Many2one('tender.line', required=1)
    description = fields.Char('Description', related="product_id.description")
    tender_type = fields.Selection(string='Type', related="product_id.type",
                                   selection=[('view', 'View'), ('action', 'Action')], required=True, default='view')
    uom_id = fields.Many2one('uom.uom', related="product_id.uom_id")
    state = fields.Selection(string='Status', related="product_id.state", selection=[('main', 'Main'), ('new', 'New')],
                             required=True, default='main')
    price_unit = fields.Float(string='Price Unit', compute="compute_contract_qty_price")
    percentage = fields.Float(string='Percentage', default=100)
    contract_qty = fields.Float(string='Contract Qty', conpute="compute_contract_qty_price")
    quantity = fields.Float(string='Current Qty')
    last_qty = fields.Float(string='Last Qty')
    price_subtotal = fields.Float(string='Price Subtotal', compute='compute_price_subtotal')
    total_qty = fields.Float(string='Total Quantity', compute='compute_qty')
    total_subtotal = fields.Float(string='Total ', compute='compute_total_subtotal')
    total_value = fields.Float(string='total', compute='computes_total', store=1)
    last_value = fields.Float(string='Last Value', store=True)
    current_value = fields.Float(string='Current Value', compute='computes_total', store=1)
    completion_rate = fields.Float(string='Completion rate', compute='computes_completion_rate', store=1)
    type = fields.Selection(string='Type', selection=[('view', 'View'), ('action', 'Action')], required=True, default='view')
    wbs_line_id = fields.Many2one(comodel_name='wbs.line', string="WBS")
    wbs_lines_ids = fields.Many2many('wbs.line')
    qs_qty = fields.Float('Qs Qty', compute="get_qs_qty", store=1)
    break_down_id = fields.Many2one(comodel_name='break.down', string="Break Down")
    break_down_line_id = fields.Many2one(comodel_name='break.down.line', string="Break Down Line")

    @api.depends('invoice_id', 'product_id')
    def get_qs_qty(self):
        for rec in self:
            rec.qs_qty = 0
            if rec.invoice_id.construction_type == 'owner':
                last_qs_id = self.env['qty.survey'].search([
                    ('project_id', '=', rec.invoice_id.contract_id.construction_project_id.id),
                    ('partner_id', '=', rec.invoice_id.contract_id.partner_id.id),
                ], order='id desc', limit=1)
                for qs_line in last_qs_id.line_ids:
                    if qs_line.tender_line_id == rec.product_id:
                        rec.qs_qty = qs_line.total_qty

    @api.depends('contract_qty', 'total_qty')
    def computes_completion_rate(self):
            for rec in self:
                if rec.total_qty >0:
                    rec.completion_rate = rec.total_qty / rec.contract_qty if rec.contract_qty > 0 else 0
                else:
                    rec.completion_rate = 0

    @api.depends('last_value', 'percentage', 'total_qty')
    def computes_total(self):
        for rec in self:
            rec.total_value = rec.total_qty * rec.price_unit * rec.percentage / 100
            rec.current_value = rec.total_value - rec.last_value

    @api.onchange('wbs_line_id', 'product_id')
    def onchange_wbs_line_id(self):
        for rec in self:
            res = {}
            lines = []
            wbs_distribution_ids = self.env['wbs.distribution'].search([
                ('project_id', '=', rec.invoice_id.construction_project_id.id),
                ('partner_id', '=', rec.invoice_id.partner_id.id),
            ])
            for wbs in wbs_distribution_ids:
                for line in wbs.line_ids:
                    if line.tender_id == rec.product_id:
                        lines.append(line.wbs_line_id.id)
            if len(lines) > 0:
                res['domain'] = {'wbs_line_id': [('id', 'in', lines)]}
            else:
                res['domain'] = {'wbs_line_id': [('id', 'in', False)]}
            print(res)
            return res
    @api.onchange('contract_line_id')
    def change_contract_line_id(self):
        for rec in self:
            rec.product_id = rec.contract_line_id.product_id.id
            print(">>>>>>>>>>>>>>>>>>>>>.. ",rec.invoice_id.construction_project_id)
            print(">>>>>>>>>>>>>>>>>>>>>.. ",rec.contract_line_id.product_id, 'xxxx', rec.contract_line_id.product_id.description)
            break_down_id = self.env['break.down'].search([
                ('project_id', '=', rec.invoice_id.construction_project_id.id),
                ('tender_line_id', '=', rec.contract_line_id.product_id.id),
            ],limit=1)
            print("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXx",break_down_id)
            rec.break_down_id = break_down_id.id
            res = {}
            if rec.invoice_id.contract_id.line_ids:
                res['domain'] = {'contract_line_id': [('id', 'in', rec.invoice_id.contract_id.line_ids.ids)]}
            else:
                res['domain'] = {'contract_line_id': [('id', 'in', False)]}
            print(res)
            return res

    @api.onchange('product_id', 'contract_line_id')
    def change_product_id_domain(self):
        res = {}
        products = []
        if self.invoice_id.construction_type == 'owner':
            last_qs_id = self.env['qty.survey'].search([
                ('project_id', '=', self.invoice_id.contract_id.construction_project_id.id),
                ('partner_id', '=', self.invoice_id.contract_id.partner_id.id),
            ], order='id desc', limit=1)
            for qs_line in last_qs_id.line_ids:
                if qs_line.tender_line_id == self.product_id:
                    self.qs_qty = qs_line.total_qty
        print("XXXXXXXXXXXXXXXXXXXXXXx ",self.contract_line_id.product_id.id)
        # for line in self.invoice_id.contract_id.line_ids:
        #     print(line.product_id.id)
        #     products.append(line.product_id.id)
        for line in self.contract_line_id:
            print(line.product_id.id)
            products.append(line.product_id.id)
        res['domain'] = {'product_id': [('id', 'in', products)]}
        return res

    @api.onchange('product_id')
    def change_product_get_wbs(self):
        for rec in self:
            lines = []
            wbs_distribution_ids = self.env['wbs.distribution'].search([
                ('project_id', '=', rec.invoice_id.construction_project_id.id),
                ('partner_id', '=', rec.invoice_id.partner_id.id),
            ])
            for wbs in wbs_distribution_ids:
                for line in wbs.line_ids:
                    if line.tender_id == rec.product_id:
                        lines.append(line.wbs_line_id.id)
            rec.wbs_lines_ids = [(6, 0, lines)]

    @api.depends('product_id')
    def compute_contract_qty_price(self):
        for rec in self:
            rec.contract_qty = 0
            rec.price_unit = 0
            for line in rec.invoice_id.contract_id.line_ids:
                if rec.product_id == line.product_id:
                    rec.contract_qty = line.quantity
                    rec.price_unit = line.price_unit

    @api.onchange('product_id')
    def change_product_id(self):
        for line in self.invoice_id.contract_id.line_ids:
            if self.product_id == line.product_id:
                self.contract_qty = line.quantity
                self.price_unit = line.price_unit
                self.type = line.tender_type
                # for line in self.invoice_id.invoice_line_ids:
        #     if self.product_id == line.product_id and line != self:
        #         raise ValidationError(_("Item [ %s ] Already Exist " % self.product_id.name))

    @api.depends('quantity')
    def compute_price_subtotal(self):
        for rec in self:
            rec.price_subtotal = 0

    @api.depends('last_qty', 'quantity')
    def compute_qty(self):
        for rec in self:
            rec.total_qty = rec.last_qty + rec.quantity

    @api.onchange('quantity')
    def _onchange_quantity_valid(self):
        pass
        # if (self.last_qty + self.quantity) > self.contract_qty:
        #     raise ValidationError(_("Total Quantity Must be les than or equal contract Quantity"))

    @api.depends('total_qty', 'price_unit')
    def compute_total_subtotal(self):
        for rec in self:
            rec.total_subtotal = rec.total_qty * rec.price_unit

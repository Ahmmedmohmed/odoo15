from odoo import models, fields, api, _
from odoo.exceptions import ValidationError


class AccountMove(models.Model):
    _inherit = 'account.move'
    project_id = fields.Many2one('construction.project', string="Project")


class AccountMoveLine(models.Model):
    _inherit = 'account.move.line'

    project_id = fields.Many2one(related="move_id.project_id", store=1)
    tender_id = fields.Many2one('tender.line', store=1)
    break_down_id = fields.Many2one(comodel_name='break.down', string="Break Down", store=1)
    break_down_line_id = fields.Many2one(comodel_name='break.down.line', string="Break Down Line", store=1)
    wbs_id = fields.Many2one('wbs.line', 'Auto WBS')

    @api.onchange('tender_id')
    def change_construct_tender_id(self):
        for rec in self:
            break_down_id = self.env['break.down'].search([
                ('project_id', '=', rec.project_id.id),
                ('tender_line_id', '=', rec.tender_id.id),
            ], limit=1)
            rec.break_down_id = break_down_id.id# wbs_id = fields.Many2one('wbs.distribution', 'Auto WBS' )


from odoo import models, fields, api, _
from odoo.exceptions import ValidationError


class Contract(models.Model):
    _name = 'contract'
    _inherit = ["mail.thread", "mail.activity.mixin"]
    _rec_name = 'construction_project_id'

    @api.model
    def create(self, vals):
        if vals['type'] == 'owner':
            vals['name'] = self.env['ir.sequence'].next_by_code('owner.contract') or _('New')

        elif vals['type'] == 'subcontractor':
            vals['name'] = self.env['ir.sequence'].next_by_code('sub.contract') or _('New')
        return super(Contract, self).create(vals)

    state = fields.Selection(
        string='State',
        selection=[('draft', 'Draft'),
                   ('confirm', 'Confirm'), ],
        required=False, default='draft')

    def action_confirm(self):
        self.state = 'confirm'

    def action_draft(self):
        self.state = 'draft'

    type = fields.Selection(string='Type', selection=[
        ('owner', 'Owner'),
        ('subcontractor', 'Subcontractor')
    ], required=True)
    name = fields.Char('Name', )
    financial_offer_id = fields.Many2one(comodel_name='financial.offer', store=1, string="Financial")
    construction_project_id = fields.Many2one(comodel_name='construction.project', required=True, string="Project")
    partner_id = fields.Many2one('res.partner', string="Customer", required=True,
                                 related="construction_project_id.partner_id")
    subcontractor_id = fields.Many2one('res.partner', string="Subcontractor", )
    contract_template_id = fields.Many2one(comodel_name='contract.template', required=True, string="Contract")
    account1_id = fields.Many2one(comodel_name='account.account', required=True,
                                  string="")  # cost account for sub counterpart accout for owner
    account2_id = fields.Many2one(comodel_name='account.account', required=True,
                                  string="")  # partner Account	for sub  counterpart for owner
    line_ids = fields.One2many(comodel_name='contract.line', inverse_name='contract_id')
    owner_line_ids = fields.One2many(comodel_name='contract.line', inverse_name='contract_id')
    addition_line_ids = fields.One2many(comodel_name='addition.line', inverse_name='contract_id', )
    deduction_line_ids = fields.One2many(comodel_name='deduction.line', inverse_name='contract_id', )
    total = fields.Float('Total', compute="compute_contract_lines_total")
    down_payment = fields.Float('Down Payment')
    down_payment_per = fields.Float('Down Payment Percentage')
    date = fields.Date(string='Date', default=fields.Date.today)
    ref = fields.Char(string='Reference')

    def action_update(self):
        for rec in self:
            for line in rec.construction_project_id.tender_line_ids:
                print(rec.line_ids.mapped('product_id'))
                if line not in rec.line_ids.mapped('product_id'):
                    line = self.env['contract.line'].create({
                        'contract_id': self.id,
                        'product_id': line.id,
                        'tender_type': line.type,
                        'quantity': line.qty,
                        'price_unit': 0,
                    })
                self.line_ids = [(4, line.id)]

    @api.onchange('down_payment')
    def change_down_per_payment(self):
        if self.total > 0:
            self.down_payment_per = self.down_payment * 100 / self.total

    @api.onchange('down_payment_per')
    def change_down_payment(self):
        self.down_payment = self.total * self.down_payment_per / 100

    @api.constrains('deduction_line_ids', 'down_payment')
    def constrains_deduction_line_ids(self):
        total_deduction = 0
        for ded in self.deduction_line_ids:
            if ded.name.down_payment:
                total_deduction += ded.contract_total_value
            if total_deduction > self.down_payment:
                raise ValidationError(_("Total Deduction Is Greater than Down Payment"))

    @api.depends('line_ids.price_unit', 'line_ids.quantity')
    def compute_contract_lines_total(self):
        for rec in self:
            total = 0
            for line in rec.line_ids:
                total += line.total
            rec.total = total

    @api.model
    def name_search(self, name, args=None, operator='ilike', limit=100):
        super(Contract, self).name_search(name)
        args = args or []
        domain = []
        if name:
            domain = ['|', '|', '|',
                      ('construction_project_id', operator, name),
                      ('partner_id', operator, name),
                      ('partner_id', operator, name),
                      ('subcontractor_id', operator, name), ]
        results = self.search(domain + args, limit=limit)
        return results.name_get()

    @api.depends('partner_id', 'construction_project_id')
    def name_get(self):
        result = []
        for rec in self:
            if rec.partner_id:
                name = ('%s - %s  %s' % (rec.construction_project_id.name, rec.partner_id.name,
                                         "-" + rec.subcontractor_id.name if rec.subcontractor_id else "",))
            else:
                name = ('%s ' % (rec.project_id.name))

            result.append((rec.id, name))
        return result

    @api.onchange('contract_template_id')
    def _onchange_contract_template(self):
        self.account2_id = self.contract_template_id.account2_id.id
        self.account1_id = self.contract_template_id.account1_id.id

    # @api.constrains('construction_project_id')
    # def constrains_construction_project_id(self):
    #     financial_offer_id = self.env['financial.offer'].search([
    #         ('partner_id', '=', self.partner_id.id),
    #         ('project_id', '', self.construction_project_id.id),
    #     ])
    #     if not  financial_offer_id:
    #         raise  ValidationError(_("please create financial offer  first"))

    @api.onchange('construction_project_id')
    def change_construction_project_id(self):
        for rec in self:
            line_ids = []
            rec.financial_offer_id = False
            if rec.construction_project_id:
                financial_offer_id = self.env['financial.offer'].search([
                    ('partner_id', '=', rec.partner_id.id),
                    ('project_id', '=', rec.construction_project_id.id),
                ])
                if not financial_offer_id:
                    raise ValidationError(_("please create financial offer first"))
                rec.financial_offer_id = financial_offer_id.id
                for lll in financial_offer_id.line_ids:
                    # print(any(str(lll.name) in word for word in self.construction_project_id.tender_line_ids.mapped('name')))
                    # print(lll.tender_id.id, " --- ", lll.tender_item_id ,"==>",  self.construction_project_id.tender_line_ids)
                    # print("---------------------------------------------------------------------------------------------")
                    if lll.tender_id.id in self.construction_project_id.tender_line_ids.ids and any(str(lll.name) in word for word in self.construction_project_id.tender_line_ids.mapped('name')):
                        line = self.env['contract.line'].create({
                            'contract_id': rec.id,
                            'break_down_id': lll.break_down_id.id,
                            'product_id': lll.tender_item_id.id,
                            'tender_type': lll.type,
                            'description': lll.description,
                            'quantity': lll.qty ,
                            'price_unit': lll.price_after_disc,
                        })
                        line_ids.append(line.id)

            rec.line_ids = [(6, 0, line_ids)]


class ContractLine(models.Model):
    _name = 'contract.line'
    _rec_name = 'description'
    contract_id = fields.Many2one(comodel_name='contract', string="Contract")
    project_id = fields.Many2one(related="contract_id.construction_project_id")
    type = fields.Selection(string='Type', related='contract_id.type')
    # product_id = fields.Many2one(comodel_name='product.product', string="Product", required=True)
    product_id = fields.Many2one(comodel_name='tender.line', string="Item", required=True)
    description = fields.Char('Description')
    break_down_id = fields.Many2one(comodel_name='break.down', string="Break Down")
    break_down_line_id = fields.Many2one(comodel_name='break.down.line', string="Break Down Line")
    tender_type = fields.Selection(string='Type', selection=[('view', 'View'), ('action', 'Action')], required=True, default='view')
    uom_id = fields.Many2one('uom.uom', related="product_id.uom_id")
    state = fields.Selection(string='Status', related="product_id.state", selection=[('main', 'Main'), ('new', 'New')],
                             required=True, default='main')
    quantity = fields.Float('Quantity', required=True)
    price_unit = fields.Float('Price Unit', required=True, )
    total = fields.Float('Total', compute='compute_total')
    #todo: remove 2 fields it in invoice not in contract
    wbs_line_id = fields.Many2one(comodel_name='wbs.line', string="WBS")
    qs_qty = fields.Float('Qs Qty')

    @api.onchange('product_id')
    def onchange_product_id(self):
        if self.product_id.type == 'view':
            self.price_unit = 0
        if not self.contract_id.construction_project_id:
            raise ValidationError(_("Please Select Project "))
        if self.contract_id.type == 'owner':

            res = {}
            lines = []
            for line in self.contract_id.construction_project_id.tender_line_ids:
                lines.append(line.id)
            if len(lines) > 0:
                res['domain'] = {'product_id': [('id', 'in', lines)]}
            else:
                res['domain'] = {'product_id': [('id', 'in', False)]}
            return res
        elif self.contract_id.type == 'subcontractor':
            res = {}
            lines = []
            wbs_distribution_ids = self.env['wbs.distribution'].search([
                ('project_id', '=', self.contract_id.construction_project_id.id),
                ('partner_id', '=', self.contract_id.partner_id.id),
            ])
            for wbs in wbs_distribution_ids:
                for line in wbs.line_ids:
                    lines.append(line.tender_id.id)
            if len(lines) > 0:
                res['domain'] = {'product_id': [('id', 'in', lines)]}
            else:
                res['domain'] = {'product_id': [('id', 'in', False)]}
            return res

    @api.depends('price_unit', 'quantity')
    def compute_total(self):
        for rec in self:
            rec.total = rec.quantity * rec.price_unit

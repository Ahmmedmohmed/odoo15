## Module <hr_biometric_attendance>

#### 23.07.2024
#### Version 15.0.1.0.0
#### ADD
- Initial commit for HR Biometric Device Integration

#### 20.12.2024
#### Version 15.0.1.1.1
#### ADD
- Verified Password before test connection, and set up multi company rules.
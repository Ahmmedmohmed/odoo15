{
    'name': 'Petty Cash',
    'author': 'Amr Yasser | Secure Tech',
    'depends': [
        'base',
        'mail',
    ],
    'data': [
        'security/security.xml',
        'security/ir.model.access.csv',
        'views/petty_cash_views.xml',
    ],
}

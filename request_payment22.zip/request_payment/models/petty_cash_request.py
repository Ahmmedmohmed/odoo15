from datetime import date

from odoo import fields, models, api
from odoo.exceptions import ValidationError


class PettyCashRequest(models.Model):
    _name = 'petty.cash.request'

    state = fields.Selection(
        selection=[
            ("draft", "Draft"),
            ("posted", "Posted"),
            ("canceled", "Canceled")
        ],
        default="draft"
    )
    reference = fields.Char()
    date = fields.Date(
        default=fields.Date.today()
    )
    journal_id = fields.Many2one(
        'account.journal',
        required=1
    )
    account_journal_ids = fields.Many2many(
        'account.journal'
    )
    petty_cash_line_ids = fields.One2many(
        'petty.cash.line',
        'petty_cash_request_id'
    )
    account_move_ids = fields.Many2many(
        'account.move'
    )
    account_move_count = fields.Integer(
        compute='compute_account_move_count'
    )

    def compute_account_move_count(self):
        for rec in self:
            account_move_count = self.env['account.move'].search_count([
                ('id', 'in', rec.account_move_ids.ids)
            ])
            if account_move_count:
                rec.account_move_count = account_move_count
            else:
                rec.account_move_count = 0

    def action_show_journal_entry(self):
        action = self.env.ref('account.action_move_journal_line').read()[0]
        if self.account_move_count > 1:
            action['domain'] = [('id', 'in', self.account_move_ids.ids)]
        elif self.account_move_count == 1:
            action['views'] = [(self.env.ref('contract.view_account_move_contract_helper_form').id, 'form')]
            action['res_id'] = self.account_move_ids.ids[0]
        else:
            action = {'type': 'ir.actions.act_window_close'}
        return action

    @api.constrains('account_journal_ids')
    def count_petty_cash_lines(self):
        for rec in self:
            rec.petty_cash_line_ids = False
            if rec.account_journal_ids:
                for journal in rec.account_journal_ids:
                    rec.petty_cash_line_ids += self.env['petty.cash.line'].create({
                        'petty_cash_journal_id': journal.id,
                        'petty_cash_request_id': rec.id,
                        'journal_id': rec.journal_id.id
                    })
            else:
                rec.petty_cash_line_ids = False

    def name_get(self):
        result = []
        for rec in self:
            name = 'Petty Cash Request - ' + str(rec.id)
            result.append((rec.id, name))
        return result

    def action_post(self):
        for rec in self:
            if not rec.petty_cash_line_ids:
                raise ValidationError("You must add a petty cash journal line to confirm request !")
            if rec.account_move_ids:
                rec.account_move_ids = False
            lines = []
            for line in rec.petty_cash_line_ids:
                lines.append((0, 0, {'account_id': line.petty_cash_journal_id.default_account_id.id,
                                     'debit': line.amount,
                                     'credit': 0.0
                                     }))
                lines.append((0, 0, {'account_id': line.journal_id.default_account_id.id,
                                     'debit': 0.0,
                                     'credit': line.amount,
                                     }))
            move = self.env['account.move'].create({
                'move_type': 'entry',
                'ref': rec.reference,
                'date': rec.date,
                'journal_id': rec.journal_id.id,
                'line_ids': lines
            })
            rec.account_move_ids += move
            rec.state = 'posted'

    def action_draft(self):
        for rec in self:
            rec.state = 'draft'

    def action_cancel(self):
        for rec in self:
            rec.state = 'canceled'

    # def compute_account_move_count(self):
    #     for rec in self:
    #         account_move_count = self.env['account.move'].search_count([
    #             ('id', '=', rec.account_move_id.id)
    #         ])
    #         if account_move_count:
    #             rec.account_move_count = account_move_count
    #         else:
    #             rec.account_move_count = 0
    #
    # def action_show_journal_entry(self):
    #     action = self.env.ref('account.action_move_journal_line').read()[0]
    #     if self.account_move_count == 1:
    #         action['views'] = [(self.env.ref('contract.view_account_move_contract_helper_form').id, 'form')]
    #         action['res_id'] = self.account_move_id.id
    #     else:
    #         action = {'type': 'ir.actions.act_window_close'}
    #     return action
    #
    # @api.model
    # def create(self, vals):
    #     if vals.get('name', '/') == '/':
    #         vals['name'] = self.env['ir.sequence'].next_by_code('petty.cash.request.sequence')
    #
    #     return super(PettyCashRequest, self).create(vals)
    #
    # def activity_schedule(self, act_type_xmlid, date_deadline, summary, note, **act_values):
    #     return super(PettyCashRequest, self).activity_schedule(
    #         act_type_xmlid,
    #         date_deadline=date_deadline,
    #         summary=summary,
    #         note=note,
    #         **act_values
    #     )
    #
    # def activity_feedback(self, act_type_xmlid, feedback):
    #     return super(PettyCashRequest, self).activity_feedback(
    #         act_type_xmlid,
    #         feedback=feedback
    #     )
    #
    # def action_request(self):
    #     self.activity_schedule('mail.mail_activity_data_todo', summary='Petty Cash Requested',
    #                            note='Please review this petty cash request', date_deadline=date.today(),
    #                            user_id=self.user.id)
    #     self.write({'state': 'requested'})
    #
    # def action_reject(self):
    #     self.activity_schedule('mail.mail_activity_data_todo', summary='Petty Cash Request Has Been Rejected',
    #                            note='', date_deadline=date.today(),
    #                            user_id=self.user.id)
    #     self.write({'state': 'rejected'})
    #
    # def approve(self):
    #     self.write({'state': 'approved'})
    #
    #     payment = self.env['account.payment'].create({
    #         'journal_id': self.payment_journal.id,
    #         'destination_journal_id': self.petty_cash_journal.id,
    #         'amount': self.request_amount,
    #         'date': self.date,
    #         'is_internal_transfer': True,
    #         'payment_type': 'inbound',
    #     })
    #
    #     self.payment = payment
    #     payment.action_post()
    #
    # def action_approve(self):
    #     if self.account_move_id:
    #         self.account_move_id = False
    #     lines = [(0, 0, {'account_id': self.petty_cash_journal.default_account_id.id,
    #                      'debit': self.request_amount,
    #                      'credit': 0.0,
    #                      }),
    #              (0, 0, {'account_id': self.payment_journal.default_account_id.id,
    #                      'debit': 0.0,
    #                      'credit': self.request_amount,
    #                      })]
    #     move = self.env['account.move'].create({
    #         'move_type': 'entry',
    #         'ref': self.name,
    #         'date': self.date,
    #         'journal_id': self.petty_cash_journal.id,
    #         'line_ids': lines
    #     })
    #     self.account_move_id = move
    #     self.activity_schedule('mail.mail_activity_data_todo', date_deadline=date.today(),
    #                            summary='Petty Cash Request Has Been Approved',
    #                            note='',
    #                            user_id=self.user.id)
    #     self.ensure_one()
    #     self.approve()

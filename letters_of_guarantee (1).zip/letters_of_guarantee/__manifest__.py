# -*- coding: utf-8 -*-
{
    'name': 'Letters Of Guarantee',
    'depends': ['base', 'project'],
    'data': [
        'security/ir.model.access.csv',
        'views/letters_of_guarantee_views.xml',
        'views/letters_of_guarantee_request.xml',
    ],
}
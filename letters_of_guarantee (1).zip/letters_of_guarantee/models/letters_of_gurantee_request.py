from odoo import fields, api, models


class LettersOfGuaranteeRequest(models.Model):
    _name = 'letters.of.guarantee.request'

    letter_type = fields.Selection([('primary', 'ابتدائي'), ('ultimate', 'نهائي'), ('advance_payment', 'دفعة مقدمة')], string="نوع الخطاب")
    beneficiary = fields.Many2one('res.partner', string='المستفيد')
    letter_length = fields.Integer('مدة الخطاب')
    project_id = fields.Many2one('project.project', 'المشروع')
    letter_value = fields.Float('قيمة الخطاب')
    percentage = fields.Float('النسبة')
    insurance_value = fields.Float(compute='_compute_insurance_value', string="قيمة التأمين")
    state = fields.Selection([('draft', 'Draft'), ('approved_ceo', 'Approved (CEO)')], default='draft')

    @api.depends('letter_value', 'percentage')
    def _compute_insurance_value(self):
        for rec in self:
            rec.insurance_value = rec.percentage/100 * rec.letter_value

    def action_approve_ceo(self):
        self.ensure_one()
        self.state = 'approved_ceo'
        self.env['letters.of.guarantee'].create({
            'letter_type': self.letter_type,
            'beneficiary': self.beneficiary.id,
            'letter_length': self.letter_length,
            'project_id': self.project_id.id,
            'letter_value': self.letter_value,
            'percentage': self.percentage,
            'insurance_value': self.insurance_value,
        })


# -*- coding: utf-8 -*-

from odoo import models, fields, api

class CarCar(models.Model):
    _name = 'car.car'
    _description = 'car'

    date_and_time = fields.Datetime(default=fields.Datetime.now,string=" التاريخ والوقت")
    car_type = fields.Char(string="نوع السيارة")
    vendor_id = fields.Many2one("res.partner",string=" المورد")
    driver = fields.Char(string="السائق")
    uom_id = fields.Many2one("uom.uom",string="الوحدة")
    quantity = fields.Integer(string="الكمية ")
    meter_reading_start = fields.Float(string="سجل قراءة عداد اول")
    meter_reading_end = fields.Float(string=" سجل قراءة عداد اخر")
    total_meter_reading_km = fields.Float(string="عدد الكيلو متر ")
    payload_type = fields.Char(string=" طبيعة الحمولة")
    move_from = fields.Char(string="من  ")
    move_to = fields.Char(string="الي ")

    billed_cars = fields.Boolean(string=" تم الفوترة ",default=False)


    def action_create_bill_from_cars(self):
        for car in self:
            bills = self.env['account.move'].create({
                'move_type': 'in_invoice',
                'partner_id': car.vendor_id.id,
                'invoice_date': fields.Date.today(),
                'invoice_line_ids': [(0, 0, {
                    'name': car.car_type,
                    'quantity': car.quantity,
                })],
            })

            car.billed_cars= True



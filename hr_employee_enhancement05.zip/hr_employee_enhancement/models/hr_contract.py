# -*- coding: utf-8 -*-
from odoo import api, fields, models, _


class HrContract(models.Model):
    _inherit = 'hr.contract'

    salary1 = fields.Monetary(
        string="Salary 1",
        currency_field='currency_id'
    )

    salary2 = fields.Monetary(
        string="Salary 2",
        currency_field='currency_id'
    )

    salary3 = fields.Monetary(
        string="Salary 3",
        currency_field='currency_id'
    )

    salary4 = fields.Monetary(
        string="Salary 4",
        currency_field='currency_id'
    )

    salary5 = fields.Monetary(
        string="Salary 5",
        currency_field='currency_id'
    )

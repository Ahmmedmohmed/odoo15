This module adds an analytic account on the purchases that is applied on all the lines.

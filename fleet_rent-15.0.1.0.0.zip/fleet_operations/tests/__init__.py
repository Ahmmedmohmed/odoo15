# -*- coding: utf-8 -*-
# See LICENSE file for full copyright and licensing details.

from . import test_vehicle_registration
from . import test_workorder
from . import test_writeoff
from . import test_vehicle_model
from . import test_vehicle_driver
from . import test_vehicle_odometer
from . import test_vehicle_cost
from . import test_repair_type
from . import test_service_type
from . import test_vehicle_status
from . import test_damage_type
from . import test_next_service_day
from . import test_vehicle_color
from . import test_vehicle_tag
from . import test_operation

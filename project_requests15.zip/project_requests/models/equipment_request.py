from odoo import fields, api, models


class EquipmentRequest(models.Model):
    _name = 'equipment.request'

    fleet_id = fields.Many2one(
        'fleet.vehicle',
        string='نوع المعدة',
        required=True,
    )
    fleet_model_id = fields.Many2one(
        'fleet.vehicle.model',
        string='الموديل',
        required=True,
    )
    qty = fields.Float(
        string='العدد المطلوب',
        required=True,
    )
    tag_ids = fields.Many2many(
        comodel_name="project.tags",
        string="العلامات"
    )
    note = fields.Char(
        string="ملاحظات"
    )
    project_id = fields.Many2one(
        'project.project',
        string='Project',
    )
    project_task_id = fields.Many2one(
        'project.task',
        string='Task',
    )

    @api.onchange('fleet_id')
    def onchange_fleet_id(self):
        for rec in self:
            rec.fleet_model_id = rec.fleet_id.model_id.id

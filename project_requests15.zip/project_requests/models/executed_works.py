from odoo import fields, api, models


class ExecutedWorks(models.Model):
    _name = 'executed.works'

    product_id = fields.Many2one(
        'product.product',
        string='البند'
    )
    uom = fields.Many2one(
        'uom.uom',
        string='وحدة القياس'
    )
    basic_quantity = fields.Float(
        string='الكمية اﻷساسية'
    )
    related_product_id = fields.Many2one(
        string='البند',
        related='product_id'
    )
    related_uom = fields.Many2one(
        string='وحدة القياس',
        related='uom'
    )
    related_basic_quantity = fields.Float(
        string='الكمية اﻷساسية',
        related='basic_quantity'
    )
    executed_quantity = fields.Float(
        string='الكمية المنفذة (ضهر عربية) لليوم الحالي (متر مكعب)',
        related='executed_project_follow_id.exchange_quantity'
    )
    ratio = fields.Float(
        string='النسبة'
    )
    current_quantity = fields.Float(
        string='الكمية المنفذة (هندسي تقديرية حتي التسليم) لليوم الحالي (متر مكعب)',
        compute='compute_values'
    )
    cumulative_executed_quantity = fields.Float(
        string='الكمية التراكمية المنفذة (ضهر عربية) حتي تاريخه (متر مكعب)',
        related='executed_project_follow_id.cumulative_exchange_quantity'
    )
    cumulative_quantity = fields.Float(
        string='الكمية التراكمية المنفذة هندسى (ما تم تسليمه + أعمال تقديرية تحت التشغيل والتسليم) (متر مكعب)',
        compute='compute_values'
    )
    rate = fields.Char(
        string='نسبة الهالك',
        compute='compute_values'
    )
    note = fields.Text(
        string="ملاحظات"
    )
    executed_project_follow_id = fields.Many2one(
        'project.follow'
    )

    def compute_values(self):
        for rec in self:
            if rec.ratio and rec.ratio > 0:
                rec.current_quantity = rec.executed_quantity - (rec.executed_quantity * rec.ratio)
                rec.cumulative_quantity = rec.cumulative_executed_quantity - (rec.cumulative_executed_quantity * rec.ratio)
            else:
                rec.current_quantity = rec.executed_quantity
                rec.cumulative_quantity = rec.cumulative_executed_quantity
            if rec.cumulative_quantity > 0:
                rec.rate = (rec.cumulative_executed_quantity / rec.cumulative_quantity) - 1
            else:
                rec.rate = 1

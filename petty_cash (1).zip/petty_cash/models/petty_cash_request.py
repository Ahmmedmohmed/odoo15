from datetime import date

from odoo import fields, models, api


class PettyCashRequest(models.Model):
    _name = 'petty.cash.request'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    STATE_SELECTION = [
        ('draft', 'Draft'),
        ('requested', 'Requested'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    ]

    name = fields.Char()
    request_to = fields.Many2one('hr.employee', string='Request To')
    request_by = fields.Many2one('hr.employee', string='Request By')
    payment_journal = fields.Many2one('account.journal', string='Payment Journal')
    petty_cash_journal = fields.Many2one('account.journal', string='Petty Cash Journal')
    date = fields.Date(string='Date')
    request_amount = fields.Float(string='Request Amount')
    user = fields.Many2one('res.users', string='User', default=lambda self: self.env.user)
    company = fields.Many2one('res.company', string='Company', default=lambda self: self.env.company)
    state = fields.Selection(STATE_SELECTION, string='State', default='draft')
    payment = fields.Many2one('account.payment', string='Payment')

    @api.model
    def create(self, vals):
        if vals.get('name', '/') == '/':
            vals['name'] = self.env['ir.sequence'].next_by_code('petty.cash.request.sequence')

        return super(PettyCashRequest, self).create(vals)

    def activity_schedule(self, act_type_xmlid, date_deadline, summary, note, **act_values):
        return super(PettyCashRequest, self).activity_schedule(
            act_type_xmlid,
            date_deadline=date_deadline,
            summary=summary,
            note=note,
            **act_values
        )

    def activity_feedback(self, act_type_xmlid, feedback):
        return super(PettyCashRequest, self).activity_feedback(
            act_type_xmlid,
            feedback=feedback
        )

    def action_request(self):
        self.activity_schedule('mail.mail_activity_data_todo', summary='Petty Cash Requested',
                               note='Please review this petty cash request', date_deadline=date.today(),
                               user_id=self.user.id)
        self.write({'state': 'requested'})

    def action_reject(self):
        self.activity_schedule('mail.mail_activity_data_todo', summary='Petty Cash Request Has Been Rejected',
                                note='', date_deadline=date.today(),
                                user_id=self.user.id)
        self.write({'state': 'rejected'})

    def approve(self):
        self.write({'state': 'approved'})

        payment = self.env['account.payment'].create({
            'journal_id': self.payment_journal.id,
            'destination_journal_id': self.petty_cash_journal.id,
            'amount': self.request_amount,
            'date': self.date,
            'is_internal_transfer': True,
            'payment_type': 'inbound',
        })

        self.payment = payment
        payment.action_post()

    def action_approve(self):
        self.activity_schedule('mail.mail_activity_data_todo', date_deadline=date.today(), summary='Petty Cash Request Has Been Approved',
                                note='',
                                user_id=self.user.id)
        self.ensure_one()
        self.approve()

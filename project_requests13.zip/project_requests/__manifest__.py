# -*- coding: utf-8 -*-
{
    'name': "Project Requests",
    'summary': "Project Requests",
    'author': "Abdelrahman Ragab",
    'version': '15.0.0.1.0',
    'category': 'others',
    'license': 'AGPL-3',
    'sequence': 1,
    'depends': [
        'base',
        'project',
        'fleet',
        'material_purchase_requisitions',
    ],
    'data': [
        'security/ir.model.access.csv',
        'views/project_view.xml',
        'views/material_purchase_requisition.xml',
        'views/project_task_view.xml',
        'views/project_follow.xml',
        'data/data.xml',
    ],
    'demo': [
    ],
    'installable': True,
    'application': True,
    'auto_install': False,
}

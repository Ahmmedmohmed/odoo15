from odoo import fields, api, models


class DailySupplies(models.Model):
    _name = 'daily.supplies'

    product_id = fields.Many2one(
        'product.product',
        string='نوع التوريد',
        required=True
    )
    basic_quantity = fields.Float(
        string='الكمية اﻷساسية',
        required=True
    )
    current_quantity = fields.Float(
        string='كمية اليوم الحالي (متر مكعب)',
        required=True
    )
    cumulative_quantity = fields.Float(
        string='الكمية التراكمية حتي تاريخه (متر مكعب)',
        required=True
    )
    note = fields.Text(
        string="ملاحظات"
    )
    daily_project_follow_id = fields.Many2one(
        'project.follow'
    )

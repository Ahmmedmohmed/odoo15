from odoo import fields, api, models


class ExecutedWorks(models.Model):
    _name = 'executed.works'

    product_id = fields.Many2one(
        'product.product',
        string='البند',
        required=True
    )
    executed_quantity = fields.Float(
        string='الكمية المنفذة (ضهر عربية) لليوم الحالي (متر مكعب)',
        required=True
    )
    current_quantity = fields.Float(
        string='الكمية المنفذة (هندسي تقديرية حتي التسليم) لليوم الحالي (متر مكعب)',
        required=True
    )
    cumulative_executed_quantity = fields.Float(
        string='الكمية التراكمية المنفذة (ضهر عربية) حتي تاريخه (متر مكعب)',
        required=True
    )
    cumulative_quantity = fields.Float(
        string='الكمية التراكمية المنفذة هندسى (ما تم تسليمه + أعمال تقديرية تحت التشغيل والتسليم) (متر مكعب)',
        required=True
    )
    old_cumulative_quantity = fields.Float(
        string='الكمية التراكمية المنفذة هندسى في القطاع القديم ويتم نقلها للقطاع الجديد(وسيتم احتسابها تشغيل ونقل داخلي) (متر مكعب)',
        required=True
    )
    rate = fields.Char(
        string='نسبة الهالك',
        required=True
    )
    note = fields.Text(
        string="ملاحظات"
    )
    executed_project_follow_id = fields.Many2one(
        'project.follow'
    )

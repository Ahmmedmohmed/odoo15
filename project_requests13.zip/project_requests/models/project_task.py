""" Initialize Project """

from dateutil.relativedelta import relativedelta

from odoo import _, api, fields, models
from odoo.exceptions import UserError, ValidationError, Warning


class ProjectTask(models.Model):
    _inherit = 'project.task'

    create_request_id = fields.One2many(
        'create.request',
        'project_task_id'
    )
    application_request_id = fields.One2many(
        'application.request',
        'project_task_id'
    )
    equipment_request_id = fields.One2many(
        'equipment.request',
        'project_task_id'
    )
    housing_request_id = fields.One2many(
        'housing.request',
        'project_task_id'
    )
    requisition_ids = fields.Many2many(
        'material.purchase.requisition'
    )

    def action_show_requisition(self):
        for rec in self:
            domain = [('id', 'in', rec.requisition_ids.ids)]
            view_tree = {
                'name': 'Requisitions',
                'view_type': 'form',
                'view_mode': 'tree,form',
                'res_model': 'material.purchase.requisition',
                'type': 'ir.actions.act_window',
                'domain': domain,
            }
            return view_tree

    def action_create_requisition(self):
        requisition_lines_list = []
        if self.create_request_id:
            create_request_lines = self.create_request_id.filtered(lambda x: x.check)
            if create_request_lines:
                for line in create_request_lines:
                    requisition_line = (0, 0, {
                        'requisition_type': 'internal',
                        'product_id': line.product_id.id,
                        'description': line.description,
                        'qty': line.qty,
                        'qty_on_hand': line.qty_on_hand,
                        'uom': line.uom.id,
                    })
                    requisition_lines_list.append(requisition_line)
                purchase_requisition = self.env['material.purchase.requisition'].create({
                    'employee_id': self.env.user.employee_id.id,
                    'department_id': self.env.user.employee_id.department_id.id,
                    'company_id': self.env.company.id,
                    'task_id': self.id,
                    'request_date': fields.Date.today(),
                    'requisition_line_ids': requisition_lines_list
                })
                self.requisition_ids += purchase_requisition
                return {
                    'name': _('Purchase Requisitions'),
                    'type': 'ir.actions.act_window',
                    'view_mode': 'form',
                    'target': 'current',
                    'res_model': 'material.purchase.requisition',
                    'res_id': purchase_requisition.id,
                    'view_id': self.env.ref('material_purchase_requisitions.material_purchase_requisition_form_view').id,
                }
            else:
                raise ValidationError('لا يوجد طلبات في حالة تأكيد')
        else:
            raise ValidationError('يجب إنشاء طلب أولاً')

# Copyright 2019 ACSONE SA/NV
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).

from odoo import fields, models, api, _


class ProjectFollow(models.Model):

    _name = "project.follow"
    _description = "Project Follow"
    _rec_name = 'project_id'

    user_id = fields.Many2one(
        'res.users',
        string='User',
        default=lambda self: self.env.user,
        readonly=1
    )
    manager_id = fields.Many2one(
        'res.users',
        string='Project Manager'
    )
    partner_id = fields.Many2one(
        'res.partner',
        string='Customer'
    )
    project_id = fields.Many2one(
        'project.project',
        string='Project Name',
        required=1
    )
    sequence = fields.Char(
        string='Sequence',
        required=True,
        copy=False,
        readonly=True,
        default=lambda self: _('New')
    )
    date = fields.Date(
        default=fields.Date.today()
    )
    daily_supplies_id = fields.One2many(
        'daily.supplies',
        'daily_project_follow_id'
    )
    remaining_quantities_id = fields.One2many(
        'remaining.quantities',
        'remaining_project_follow_id'
    )
    result_quantities_id = fields.One2many(
        'result.quantities',
        'result_project_follow_id'
    )
    executed_works_id = fields.One2many(
        'executed.works',
        'executed_project_follow_id'
    )
    heavy_equipment_id = fields.One2many(
        'heavy.equipment',
        'heavy_project_follow_id'
    )
    problems_equipment_id = fields.One2many(
        'project.problems',
        'problems_project_follow_id'
    )

    @api.model
    def create(self, vals):
        if vals.get('sequence', _('New')) == _('New'):
            vals['sequence'] = self.env['ir.sequence'].next_by_code('project.follow') or _('New')
            return super(ProjectFollow, self).create(vals)

    @api.onchange('project_id')
    @api.constrains('project_id')
    def onchange_project_id(self):
        for rec in self:
            rec.manager_id = rec.project_id.user_id.id
            rec.partner_id = rec.project_id.partner_id.id


from odoo import fields, api, models


class HeavyEquipment(models.Model):
    _name = 'heavy.equipment'

    fleet_id = fields.Many2one(
        'fleet.vehicle',
        string='المعدة',
        required=True
    )
    partner_id = fields.Many2one(
        'res.partner',
        string='المورد',
        required=True
    )
    work_hours = fields.Float(
        string='عدد ساعات العمل',
        required=True
    )
    unit = fields.Float(
        string='الوحدة',
        required=True
    )
    rosary = fields.Selection([
        ('am', 'ص'),
        ('pm', 'م')],
        string="الوردية",
        required=True
    )
    work = fields.Float(
        string='مكان وطبيعة العمل',
        required=True
    )
    reason = fields.Text(
        string="سبب العطل ان وجد"
    )
    note = fields.Text(
        string="ملاحظات"
    )
    heavy_project_follow_id = fields.Many2one(
        'project.follow'
    )

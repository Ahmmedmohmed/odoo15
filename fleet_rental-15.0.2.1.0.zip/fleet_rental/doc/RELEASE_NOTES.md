## Module <fleet_rental>

#### 03.12.2020
#### Version 15.0.1.0.0
#### ADD

- Initial Commit for Fleet Rental Management

#### 26.09.2023
#### Version 15.0.2.0.0
#### UPDT

- Rental fleet Invoice product selection from Configuration Settings.

#### 17.10.2023
#### Version 15.0.2.1.0
#### UPDT

- Reformatted code for invoice cancellation.

#### 22.12.2023
#### Version 15.0.2.2.1
#### UPDT

- Reformatted code for hourly payment,  extend rent.
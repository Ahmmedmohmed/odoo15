* `Tecnativa <https://www.tecnativa.com>`_:

  * Luis M. Ontalba
  * Pedro M. Baeza
  * Víctor Martínez

* Levent Karakaş
* Bejaoui Souheil <souheil.bejaoui@acsone.eu>
* Dhara Solanki <dhara.solanki@initos.com>
* Joan Mateu <joan.mateu@forgeflow.com>

#. Log with an user having sale but not account permissions.
#. Go to Sales > Sales > Contracts.
#. Create a new record or edit another one.

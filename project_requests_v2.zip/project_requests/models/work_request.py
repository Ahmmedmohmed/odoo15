
from odoo import fields, models, api, _


class WorkRequest(models.Model):

    _name = "work.request"
    _rec_name = 'vehicle_request_id'

    vehicle_request_id = fields.Many2one(
        'vehicle.request'
    )
    project_id = fields.Many2one(
        'project.project',
        string='المشروع'
    )
    partner_id = fields.Many2one(
        'res.partner',
        string='Customer'
    )
    date = fields.Date()
    company_id = fields.Many2one(
        'res.company'
    )
    user_id = fields.Many2one(
        'res.users',
        string='Project Manager'
    )
    tag_ids = fields.Many2many(
        'project.tags',
        string='Tags'
    )
    work_request_lines = fields.One2many(
        'work.request.line',
        'work_request_id'
    )
    state = fields.Selection(
        [('draft', 'Draft'),
         ('open', 'Open'),
         ('closed', 'Closed')],
        default='draft'
    )

    def action_open(self):
        for rec in self:
            rec.state = 'open'

    def action_close(self):
        for rec in self:
            rec.state = 'closed'


class WorkRequestLine(models.Model):

    _name = "work.request.line"

    work_request_id = fields.Many2one(
        'work.request'
    )
    description = fields.Char(
        required=True
    )
    fleet_id = fields.Many2one(
        'fleet.vehicle',
        string='نوع المعدة'
    )
    fleet_model_id = fields.Many2one(
        'fleet.vehicle.model',
        string='الموديل',
        related='fleet_id.model_id'
    )
    qty = fields.Float(
        string='العدد المطلوب',
        required=True,
    )
    tag_ids = fields.Many2many(
        comodel_name="project.tags",
        string="العلامات"
    )
    note = fields.Char(
        string="ملاحظات"
    )
    supplier_id = fields.Many2one(
        'res.partner',
        string='المورد'
    )
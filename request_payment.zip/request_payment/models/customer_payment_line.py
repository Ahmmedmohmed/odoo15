
from odoo import fields, models, api, _


class CustomerPaymentLine(models.Model):

    _name = "customer.payment.line"

    customer_id = fields.Many2one(
        'res.partner',
        required=1
    )
    account_id = fields.Many2one(
        'account.account',
        related='customer_id.property_account_receivable_id'
    )
    vendor_account_id = fields.Many2one(
        'account.account',
        related='customer_id.property_account_payable_id'
    )
    journal_id = fields.Many2one(
        'account.journal',
        required=1
    )
    currency_id = fields.Many2one(
        'res.currency'
    )
    amount = fields.Monetary(
        'currency_id'
    )
    memo = fields.Char()
    customer_payment_id = fields.Many2one(
        'customer.payment'
    )
    vendor_payment_id = fields.Many2one(
        'vendor.payment'
    )

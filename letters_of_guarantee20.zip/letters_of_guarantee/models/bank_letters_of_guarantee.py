from odoo import fields, api, models, _


class BankLettersOfGuarantee(models.Model):
    _name = 'bank.letters.of.guarantee'
    _rec_name = 'sequence_bank'

    journal_id = fields.Many2one(
        'account.journal',
        domain="[('type', '=', 'bank')]",
        string='البنك'
    )
    sequence_bank = fields.Char(
        string='Name',
        required=True,
        copy=False,
        readonly=True,
        default=lambda self: _('New')
    )

    @api.model
    def create(self, vals):
        if vals.get('sequence_bank', _('New')) == _('New'):
            vals['sequence_bank'] = self.env['ir.sequence'].next_by_code('bank.letters.of.guarantee') or _('New')
            return super(BankLettersOfGuarantee, self).create(vals)

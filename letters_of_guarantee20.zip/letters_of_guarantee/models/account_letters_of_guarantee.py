from odoo import fields, api, models, _


class AccountLettersOfGuarantee(models.Model):
    _name = 'account.letters.of.guarantee'
    _rec_name = 'sequence_account'

    account_id = fields.Many2one(
        'account.account',
        string='غطاء خطابات الضمان'
    )
    account_purchase_id = fields.Many2one(
        'account.account',
        string='مصروفات خطاب الضمان'
    )
    sequence_account = fields.Char(
        string='Name',
        required=True,
        copy=False,
        readonly=True,
        default=lambda self: _('New')
    )

    @api.model
    def create(self, vals):
        if vals.get('sequence_account', _('New')) == _('New'):
            vals['sequence_account'] = self.env['ir.sequence'].next_by_code('account.letters.of.guarantee') or _('New')
            return super(AccountLettersOfGuarantee, self).create(vals)

from odoo import fields, models, api
from datetime import timedelta
from odoo.exceptions import ValidationError


class LettersOfGuarantee(models.Model):
    _name = 'letters.of.guarantee'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    bank = fields.Char('Bank')
    letter_type = fields.Selection([('primary', 'ابتدائي'), ('ultimate', 'نهائي'), ('advance_payment', 'دفعة مقدمة')],
                                   string="نوع الخطاب")
    beneficiary = fields.Many2one('res.partner')
    customer_id = fields.Many2one('contract.contract', string="Contract")
    letter_number = fields.Char('Letter Number')
    release_date = fields.Date('Release Date')
    letter_length = fields.Integer('مدة الخطاب')
    purpose = fields.Char("الغرض من الاصدار")
    old_expiry_date = fields.Date(string='Expiry Date')
    expiry_date = fields.Date(compute='_compute_expiry_date', string='New Expiry Date')
    extend = fields.Integer(default=0, string='فترة التمديد')
    project_id = fields.Many2one('project.project', 'Project')
    letter_value = fields.Float('Letter Value')
    insurance_value = fields.Float(compute='_compute_insurance_value', string='قيمة التأمين')
    percentage = fields.Float('النسبة')
    letter_state = fields.Selection([('in_progress', 'In Progress'), ('expired', 'Expired')], string='Letter State')
    bank_response_date = fields.Date('Bank Response Date')
    bank_response = fields.Char('Bank Response')
    state = fields.Selection(
        [('extended', 'ممتد'),
         ('returned', 'مردود')]
    )
    request_id = fields.Many2one('letters.of.guarantee.request')
    end_date_extension_line = fields.One2many(
        'guarantee.extension.line',
        'guarantee_id'
    )
    is_appear_return = fields.Boolean(
        default=False
    )
    date = fields.Date(
        string='Date',
        default=fields.Date.today()
    )
    bank_letters_of_guarantee_id = fields.Many2one(
        'bank.letters.of.guarantee',
        string='Bank Of Guarantee'
    )
    account_move_ids = fields.Many2many(
        'account.move'
    )
    account_move_count = fields.Integer(
        compute='compute_account_move_count'
    )

    def compute_account_move_count(self):
        for rec in self:
            account_move_count = self.env['account.move'].search_count([
                ('id', 'in', rec.account_move_ids.ids)
            ])
            if account_move_count:
                rec.account_move_count = account_move_count
            else:
                rec.account_move_count = 0

    def action_show_journal_entry(self):
        action = self.env.ref('account.action_move_journal_line').read()[0]
        if self.account_move_count > 1:
            action['context'] = "{'default_journal_type': 'bank'}"
            action['domain'] = [('journal_id.type', '=', 'bank'), ('id', 'in', self.account_move_ids.ids)]
        elif self.account_move_count == 1:
            action['views'] = [(self.env.ref('contract.view_account_move_contract_helper_form').id, 'form')]
            action['res_id'] = self.account_move_ids.ids[0]
        else:
            action = {'type': 'ir.actions.act_window_close'}
        return action

    def action_approve_cfo(self):
        if not self.bank_letters_of_guarantee_id:
            raise ValidationError('Please choose the bank of guarantee !')
        accounting_record = self.env['account.letters.of.guarantee'].search([], limit=1)
        if accounting_record:
            lines = [(0, 0, {'account_id': accounting_record.account_id.id,
                             'debit': self.letter_value,
                             'credit': 0.0,
                             'partner_id': self.beneficiary.id,
                             }),
                     (0, 0, {'account_id': self.bank_letters_of_guarantee_id.journal_id.default_account_id.id,
                             'debit': 0.0,
                             'credit': self.letter_value,
                             'partner_id': self.beneficiary.id,
                             })]
            move = self.env['account.move'].create({
                'move_type': 'entry',
                'ref': 'Letters Of Guarantee' + '/' + str(self.id),
                'date': self.date,
                'journal_id': self.bank_letters_of_guarantee_id.journal_id.id,
                'line_ids': lines
            })
            self.account_move_ids += move
        else:
            raise ValidationError('Please enter the account in configuration !')
        self.is_appear_return = True

    def action_extend(self):
        if not self.bank_letters_of_guarantee_id:
            raise ValidationError('Please choose the bank of guarantee !')
        accounting_record = self.env['account.letters.of.guarantee'].search([], limit=1)
        if accounting_record:
            lines = [(0, 0, {'account_id': accounting_record.account_purchase_id.id,
                             'debit': self.letter_value,
                             'credit': 0.0,
                             'partner_id': self.beneficiary.id,
                             }),
                     (0, 0, {'account_id': self.bank_letters_of_guarantee_id.journal_id.default_account_id.id,
                             'debit': 0.0,
                             'credit': self.letter_value,
                             'partner_id': self.beneficiary.id,
                             })]
            move = self.env['account.move'].create({
                'move_type': 'entry',
                'ref': 'Letters Of Guarantee' + '/' + str(self.id),
                'date': self.date,
                'journal_id': self.bank_letters_of_guarantee_id.journal_id.id,
                'line_ids': lines
            })
            self.account_move_ids += move
        else:
            raise ValidationError('Please enter the account in configuration !')
        self.state = 'extended'

    def action_return(self):
        if not self.bank_letters_of_guarantee_id:
            raise ValidationError('Please choose the bank of guarantee !')
        accounting_record = self.env['account.letters.of.guarantee'].search([], limit=1)
        if accounting_record:
            lines = [(0, 0, {'account_id': self.bank_letters_of_guarantee_id.journal_id.default_account_id.id,
                             'debit': self.letter_value,
                             'credit': 0.0,
                             'partner_id': self.beneficiary.id,
                             }),
                     (0, 0, {'account_id': accounting_record.account_id.id,
                             'debit': 0.0,
                             'credit': self.letter_value,
                             'partner_id': self.beneficiary.id,
                             })]
            move = self.env['account.move'].create({
                'move_type': 'entry',
                'ref': 'Letters Of Guarantee' + '/' + str(self.id),
                'date': self.date,
                'journal_id': self.bank_letters_of_guarantee_id.journal_id.id,
                'line_ids': lines
            })
            self.account_move_ids += move
        else:
            raise ValidationError('Please enter the account in configuration !')
        self.state = 'returned'

    @api.depends('letter_value', 'percentage')
    def _compute_insurance_value(self):
        for rec in self:
            rec.insurance_value = rec.percentage / 100 * rec.letter_value

    # @api.depends('release_date', 'extend', 'letter_length')
    # def _compute_expiry_date(self):
    #     for record in self:
    #         if record.release_date and record.letter_length:
    #             length = record.letter_length + record.extend
    #             record.expiry_date = record.release_date + timedelta(days=length)
    #         else:
    #             record.expiry_date = False

    @api.depends('end_date_extension_line')
    def _compute_expiry_date(self):
        for rec in self:
            lines = rec.env['guarantee.extension.line'].sudo().search(
                [('guarantee_id', '=', rec.id), ('check', '=', True)])
            if lines:
                rec.expiry_date = lines[-1].new_extension_date
            else:
                rec.expiry_date = False


class Project(models.Model):
    _inherit = 'project.project'

    def action_open_letters_of_guarantee(self):
        letters_of_guarantee = self.env['letters.of.guarantee'].search([('project_id', '=', self.id)])
        action = self.env.ref('letters_of_guarantee.action_letters_of_guarantee').read()[0]
        action['domain'] = [('id', 'in', letters_of_guarantee.ids)]
        return action


class GuaranteeExtensionDateLine(models.Model):
    _name = 'guarantee.extension.line'
    _description = 'Guarantee Date Line'

    name = fields.Char(
        string="name"
    )
    new_extension_date = fields.Date(
        string="New Expiry Date"
    )
    check = fields.Boolean(
        string="Check"
    )
    guarantee_id = fields.Many2one(
        'letters.of.guarantee'
    )

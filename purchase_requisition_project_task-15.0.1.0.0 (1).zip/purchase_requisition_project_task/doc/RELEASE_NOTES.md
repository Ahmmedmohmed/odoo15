## Module <purchase_requisition_project_task>

#### 02.12.2023
#### Version 15.0.1.0.0
#### ADD

- Initial Commit for Purchase Requisition and Project Task Integration

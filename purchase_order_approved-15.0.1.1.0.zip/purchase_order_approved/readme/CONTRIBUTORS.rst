* Lois Rilo <lois.rilo@forgeflow.com>
* Rattapong Chokmasermkul <rattapongc@ecosoft.co.th>
* Laurent Mignon <laurent.mignon@acsone.eu>
* Moaad Bourhim <moaad.bourhim@gmail.com>
* David Alonso <david.alonso@solvos.es>

# -*- coding: utf-8 -*-

from odoo import models, fields, api


class LettersOfGuarantee(models.Model):
    _inherit = 'letters.of.guarantee'

    contract_id = fields.Many2one('contract.contract')

# -*- coding: utf-8 -*-
# from odoo import http


# class UpdateLettersOfGuarantee(http.Controller):
#     @http.route('/update_letters_of_guarantee/update_letters_of_guarantee', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/update_letters_of_guarantee/update_letters_of_guarantee/objects', auth='public')
#     def list(self, **kw):
#         return http.request.render('update_letters_of_guarantee.listing', {
#             'root': '/update_letters_of_guarantee/update_letters_of_guarantee',
#             'objects': http.request.env['update_letters_of_guarantee.update_letters_of_guarantee'].search([]),
#         })

#     @http.route('/update_letters_of_guarantee/update_letters_of_guarantee/objects/<model("update_letters_of_guarantee.update_letters_of_guarantee"):obj>', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('update_letters_of_guarantee.object', {
#             'object': obj
#         })
